import React from 'react';
import { LEGAL, USES_ANALYTICS, USES_MARKETING, LegalKey } from './consent';

export function legal(key: LegalKey): React.ReactNode {
  const val = LEGAL[key];
  if (val && val.trim() !== '') {
    return val;
  }
  if (key === 'razaoSocial' || key === 'encarregado') {
    return null;
  }
  return <mark className="todo">{`[PREENCHER: ${key}]`}</mark>;
}

export interface LegalSectionItem {
  id: string;
  title: string;
}

export const PRIVACIDADE_SECTIONS: LegalSectionItem[] = [
  { id: 'quem-somos', title: 'Quem somos' },
  { id: 'dados', title: 'Quais dados tratamos e para quê' },
  { id: 'formularios', title: 'Como funcionam os formulários' },
  { id: 'compartilhamento', title: 'Com quem compartilhamos' },
  { id: 'transferencia', title: 'Transferência internacional' },
  { id: 'retencao', title: 'Por quanto tempo guardamos os dados' },
  { id: 'direitos', title: 'Os seus direitos' },
  { id: 'seguranca', title: 'Segurança' },
  { id: 'menores', title: 'Menores de idade' },
  { id: 'moodle', title: 'O Moodle e o login' },
  { id: 'cookies-sec', title: 'Cookies' },
  { id: 'alteracoes', title: 'Alterações' },
];

export const COOKIES_SECTIONS: LegalSectionItem[] = [
  { id: 'o-que-sao', title: 'O que são' },
  { id: 'o-que-usamos', title: 'O que usamos neste site' },
  { id: 'terceiros', title: 'Serviços de terceiros' },
  ...(!USES_ANALYTICS && !USES_MARKETING ? [{ id: 'nao-usamos', title: 'O que não usamos' }] : []),
  { id: 'gerenciar', title: 'Como mudar a sua escolha' },
  { id: 'registro', title: 'Registro da sua escolha' },
  { id: 'atualizacoes', title: 'Atualizações' },
];

export function PrivacidadeContent(_props: { onOpenPreferences?: () => void } = {}) {
  return (
    <>
      <section id="quem-somos" className="legal-section" data-section="quem-somos">
        <h2 className="legal-section-h2">Quem somos</h2>
        <p className="legal-p">
          A CorpWise{LEGAL.razaoSocial && LEGAL.razaoSocial.trim() !== '' ? ` (${LEGAL.razaoSocial})` : ''}, inscrita no CNPJ {legal('cnpj')}, com sede em {legal('endereco')}, é a controladora dos dados pessoais tratados neste site. Somos uma empresa de Moodle: integramos, configuramos, personalizamos e damos suporte à plataforma para empresas.
        </p>
        <p className="legal-p">
          Para assuntos de privacidade, fale com a gente pelo e-mail {legal('email')}.
        </p>
        {LEGAL.encarregado && LEGAL.encarregado.trim() !== '' && (
          <p className="legal-p">
            Encarregado pelo tratamento de dados pessoais: {LEGAL.encarregado}.
          </p>
        )}
      </section>

      <section id="dados" className="legal-section" data-section="dados">
        <h2 className="legal-section-h2">Quais dados tratamos e para quê</h2>
        <div className="legal-table-container">
          <table className="legal-table">
            <thead>
              <tr>
                <th>Situação</th>
                <th>Dados</th>
                <th>Finalidade</th>
                <th>Base legal (LGPD)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Formulário de contato</td>
                <td>Nome, e-mail, empresa e mensagem.</td>
                <td>Responder ao seu contato e preparar uma proposta.</td>
                <td>Procedimentos preliminares relacionados a contrato, a pedido do titular (art. 7º, V).</td>
              </tr>
              <tr>
                <td>Pedido de degustação</td>
                <td>Nome, e-mail, empresa, telefone (opcional), quantas pessoas vão testar, interesses e observações (opcionais).</td>
                <td>Criar o seu usuário de teste no nosso Moodle e responder ao pedido.</td>
                <td>Procedimentos preliminares relacionados a contrato, a pedido do titular (art. 7º, V).</td>
              </tr>
              <tr>
                <td>Mensagens enviadas para o nosso e-mail</td>
                <td>Os dados que você escrever na mensagem.</td>
                <td>Atender e acompanhar a sua solicitação.</td>
                <td>Procedimentos preliminares relacionados a contrato, a pedido do titular (art. 7º, V).</td>
              </tr>
              <tr>
                <td>Registro técnico de acesso ao site</td>
                <td>Endereço IP, tipo de navegador, data e hora do acesso.</td>
                <td>Segurança e funcionamento do site, feito pelo provedor de hospedagem.</td>
                <td>Legítimo interesse (art. 7º, IX).</td>
              </tr>
              <tr>
                <td>Escolhas de cookies e preferências</td>
                <td>A sua escolha sobre cookies e, se você permitir, o tema claro ou escuro, guardados no seu navegador.</td>
                <td>Respeitar a sua escolha e lembrar as suas preferências.</td>
                <td>Legítimo interesse, para registrar a escolha sobre cookies (art. 7º, IX), e consentimento, para lembrar o tema (art. 7º, I).</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="legal-p" style={{ fontSize: '14.5px', color: 'var(--muted)' }}>
          Pedimos apenas o necessário. Os campos marcados como opcionais podem ficar em branco.
        </p>
      </section>

      <section id="formularios" className="legal-section" data-section="formularios">
        <h2 className="legal-section-h2">Como funcionam os formulários</h2>
        <p className="legal-p">
          Os formulários deste site não enviam os seus dados sozinhos. Quando você preenche e confirma, abrimos o Gmail, ou o seu aplicativo de e-mail, com a mensagem já escrita. Os dados só chegam até nós quando você clica em Enviar. Se você fechar a janela sem enviar, não recebemos nada.
        </p>
        <p className="legal-p">
          Ao usar o Gmail, o Google também trata a sua mensagem, de acordo com a política de privacidade dele.
        </p>
      </section>

      <section id="compartilhamento" className="legal-section" data-section="compartilhamento">
        <h2 className="legal-section-h2">Com quem compartilhamos</h2>
        <ul className="legal-bullet-list">
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>{legal('hospedagem')}, provedor que armazena e entrega as páginas deste site e registra dados técnicos de acesso.</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>O provedor do nosso e-mail corporativo, que recebe as mensagens enviadas para {legal('email')}.</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>O Google, quando você escolhe enviar a mensagem pelo Gmail e para carregar a fonte de texto do site.</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>Autoridades públicas, quando houver obrigação legal.</span>
          </li>
        </ul>
        <p className="legal-p">
          Não vendemos dados pessoais.
        </p>
      </section>

      <section id="transferencia" className="legal-section" data-section="transferencia">
        <h2 className="legal-section-h2">Transferência internacional</h2>
        <p className="legal-p">
          Alguns dos prestadores citados, como o provedor de hospedagem e o Google, podem tratar dados em outros países. Quando isso acontece, a transferência segue as hipóteses previstas no art. 33 da LGPD.
        </p>
      </section>

      <section id="retencao" className="legal-section" data-section="retencao">
        <h2 className="legal-section-h2">Por quanto tempo guardamos os dados</h2>
        <p className="legal-p">
          Guardamos os dados pelo tempo necessário para cumprir a finalidade para a qual foram informados e, em regra, por até {legal('retencao')} após o último contato, salvo quando a lei exigir um prazo maior ou houver contrato em andamento. Depois disso, eliminamos ou anonimizamos os dados.
        </p>
      </section>

      <section id="direitos" className="legal-section" data-section="direitos">
        <h2 className="legal-section-h2">Os seus direitos</h2>
        <p className="legal-p">
          Você pode pedir a qualquer momento, de forma gratuita:
        </p>
        <ul className="legal-bullet-list">
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>confirmação de que tratamos dados seus</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>acesso aos dados</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>correção de dados incompletos, inexatos ou desatualizados</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>anonimização, bloqueio ou eliminação de dados desnecessários ou tratados em desacordo com a lei</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>portabilidade dos dados, nos termos da regulamentação</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>eliminação dos dados tratados com o seu consentimento</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>informação sobre com quem compartilhamos os seus dados</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>informação sobre a possibilidade de não dar consentimento e as consequências</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>revogação do consentimento</span>
          </li>
        </ul>
        <p className="legal-p">
          Para exercer qualquer um desses direitos, escreva para {legal('email')}. Podemos pedir informações para confirmar a sua identidade. Responderemos nos prazos previstos na LGPD e na regulamentação da ANPD.
        </p>
        <p className="legal-p">
          Se achar que algo não foi resolvido, você também pode apresentar uma reclamação à Autoridade Nacional de Proteção de Dados (ANPD), em{' '}
          <a
            href="https://www.gov.br/anpd"
            target="_blank"
            rel="noopener noreferrer"
            style={{ color: 'var(--link)', textDecoration: 'underline' }}
          >
            gov.br/anpd
          </a>.
        </p>
      </section>

      <section id="seguranca" className="legal-section" data-section="seguranca">
        <h2 className="legal-section-h2">Segurança</h2>
        <p className="legal-p">
          Usamos conexão segura (HTTPS), coletamos apenas o necessário e limitamos o acesso interno às mensagens recebidas a quem precisa delas para atender você.
        </p>
      </section>

      <section id="menores" className="legal-section" data-section="menores">
        <h2 className="legal-section-h2">Menores de idade</h2>
        <p className="legal-p">
          Este site é voltado a empresas e não é direcionado a menores de 18 anos.
        </p>
      </section>

      <section id="moodle" className="legal-section" data-section="moodle">
        <h2 className="legal-section-h2">O Moodle e o login</h2>
        <p className="legal-p">
          O acesso à plataforma Moodle, em corpwisegestao.com.br, acontece em um ambiente separado deste site, que pode ter regras e avisos próprios. Se você é aluno ou usuário do Moodle de uma empresa que contratou a CorpWise, fale primeiro com a sua empresa sobre os seus dados nesse ambiente.
        </p>
      </section>

      <section id="cookies-sec" className="legal-section" data-section="cookies-sec">
        <h2 className="legal-section-h2">Cookies</h2>
        <p className="legal-p">
          Veja como usamos cookies e armazenamento no navegador na nossa{' '}
          <a href="#/cookies" style={{ color: 'var(--link)', textDecoration: 'underline' }}>
            Política de Cookies
          </a>.
        </p>
      </section>

      <section id="alteracoes" className="legal-section" data-section="alteracoes">
        <h2 className="legal-section-h2">Alterações</h2>
        <p className="legal-p">
          Podemos atualizar esta política. A versão e a data da última atualização ficam no topo desta página.
        </p>
      </section>
    </>
  );
}

export function CookiesContent({ onOpenPreferences }: { onOpenPreferences?: () => void } = {}) {
  return (
    <>
      <section id="o-que-sao" className="legal-section" data-section="o-que-sao">
        <h2 className="legal-section-h2">O que são</h2>
        <p className="legal-p">
          São arquivos ou registros que um site guarda no seu navegador para funcionar, lembrar escolhas ou, em alguns casos, medir o uso do site. Alguns são indispensáveis; outros dependem da sua permissão.
        </p>
      </section>

      <section id="o-que-usamos" className="legal-section" data-section="o-que-usamos">
        <h2 className="legal-section-h2">O que usamos neste site</h2>
        <div className="legal-table-container">
          <table className="legal-table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Categoria</th>
                <th>Para que serve</th>
                <th>Duração</th>
                <th>Base legal</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><code>cw-consent</code></td>
                <td>Estritamente necessário</td>
                <td>Guarda a sua escolha sobre cookies.</td>
                <td>12 meses</td>
                <td>Legítimo interesse (art. 7º, IX)</td>
              </tr>
              <tr>
                <td><code>cw-theme</code></td>
                <td>Preferências</td>
                <td>Lembra se você escolheu o modo claro ou escuro.</td>
                <td>Até você limpar os dados do navegador ou revogar a permissão</td>
                <td>Consentimento (art. 7º, I)</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p className="legal-p" style={{ fontSize: '14px', color: 'var(--muted)' }}>
          Estes dois itens ficam no armazenamento local do seu navegador e não são enviados aos nossos servidores.
        </p>
      </section>

      <section id="terceiros" className="legal-section" data-section="terceiros">
        <h2 className="legal-section-h2">Serviços de terceiros</h2>
        <ul className="legal-bullet-list">
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>Fontes do Google (Google Fonts): para exibir a fonte de texto do site, o seu navegador faz uma requisição aos servidores do Google, que recebem o seu endereço IP. Não usamos esse recurso para identificar ou acompanhar você.</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>Links para outros sites, como o Instagram: ao clicar, você sai do nosso site e passa a seguir as regras do outro serviço.</span>
          </li>
          <li className="legal-bullet-item">
            <span className="legal-bullet-dot" />
            <span>Moodle: o login em corpwisegestao.com.br usa cookies próprios de sessão, que fazem parte do funcionamento daquele ambiente.</span>
          </li>
        </ul>
      </section>

      {!USES_ANALYTICS && !USES_MARKETING && (
        <section id="nao-usamos" className="legal-section" data-section="nao-usamos">
          <h2 className="legal-section-h2">O que não usamos</h2>
          <p className="legal-p">
            Hoje não usamos cookies de publicidade, de análise de audiência nem de redes sociais neste site.
          </p>
        </section>
      )}

      <section id="gerenciar" className="legal-section" data-section="gerenciar">
        <h2 className="legal-section-h2">Como mudar a sua escolha</h2>
        <p className="legal-p">
          Você pode rever ou revogar a sua escolha quando quiser, pelo botão abaixo ou pelo link “Preferências de cookies” no rodapé de qualquer página. Recusar os cookies que não são necessários não impede o uso do site.
        </p>
        <div style={{ margin: '14px 0' }}>
          <button
            type="button"
            className="btn lg"
            onClick={() => (onOpenPreferences ? onOpenPreferences() : window.CWConsent?.openPreferences())}
            style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
          >
            <span className="lbl">Abrir preferências de cookies</span>
            <span className="dot">
              <svg className="chev" width="16" height="16" viewBox="0 0 12 12" fill="none">
                <path
                  d="M4.5 2.5 8 6l-3.5 3.5"
                  stroke="#0b1d3a"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </span>
          </button>
        </div>
        <p className="legal-p">
          Você também pode apagar os dados do site nas configurações do seu navegador.
        </p>
      </section>

      <section id="registro" className="legal-section" data-section="registro">
        <h2 className="legal-section-h2">Registro da sua escolha</h2>
        <p className="legal-p">
          Guardamos no seu próprio navegador a data e o tipo da escolha que você fez, para respeitá-la nas próximas visitas e permitir que você a revogue.
        </p>
      </section>

      <section id="atualizacoes" className="legal-section" data-section="atualizacoes">
        <h2 className="legal-section-h2">Atualizações</h2>
        <p className="legal-p">
          Podemos atualizar esta política. A versão e a data ficam no topo desta página. Se houver mudança relevante, pediremos a sua escolha novamente.
        </p>
      </section>
    </>
  );
}
