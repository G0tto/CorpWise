// LGPD Consent Engine (Vanilla JS / TypeScript)
// Central configuration - fill in before publishing
export const LEGAL = {
  razaoSocial: '',     // company legal name (optional, defaults to CorpWise)
  cnpj: '66.259.655/0001-97',
  endereco: 'Limeira/SP',        // street, number, city, state
  encarregado: '',     // data protection officer name; leave empty if there is none
  email: 'atendimento@corpwisegestao.com.br',
  hospedagem: 'Netlify, Inc.',
  retencao: '12 meses',
  versao: '1.0',
  atualizadoEm: '',    // e.g. '10 de novembro de 2026'
};

export const USES_ANALYTICS = false;  // set to true only if an analytics tool is added later
export const USES_MARKETING = false;  // set to true only if ads or pixels are added later

export type LegalKey = keyof typeof LEGAL;

// Warn once on load for missing legal keys (except encarregado and razaoSocial which are optional)
if (typeof window !== 'undefined') {
  const missingKeys = (Object.keys(LEGAL) as LegalKey[]).filter(
    (k) => k !== 'encarregado' && k !== 'razaoSocial' && (!LEGAL[k] || LEGAL[k].trim() === '')
  );
  if (missingKeys.length > 0) {
    console.warn('LEGAL incompleto:', missingKeys);
  }
}

export interface ConsentChoices {
  necessary: true;
  preferences: boolean;
  analytics?: boolean;
  marketing?: boolean;
}

export type ConsentSource = 'aceitar-tudo' | 'recusar' | 'personalizado';

export interface ConsentRecord {
  v: 1;
  ts: string;
  policy: string;
  source: ConsentSource;
  choices: ConsentChoices;
  categories: ConsentChoices;
}

const STORAGE_KEY = 'cw-consent';
const MAX_AGE_MS = 365 * 24 * 60 * 60 * 1000; // 12 months

// In-memory fallback if localStorage is disabled or throws
let memoryConsent: ConsentRecord | null = null;
const changeListeners = new Set<(choices: ConsentChoices) => void>();
let openPreferencesHandler: (() => void) | null = null;

export function registerPreferencesOpener(fn: () => void) {
  openPreferencesHandler = fn;
}

export function readStoredConsent(): ConsentRecord | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return memoryConsent;
    const parsed = JSON.parse(raw);
    if (!parsed || parsed.v !== 1 || !parsed.ts || parsed.policy !== LEGAL.versao) {
      return null;
    }
    const age = Date.now() - new Date(parsed.ts).getTime();
    if (isNaN(age) || age < 0 || age > MAX_AGE_MS) {
      return null;
    }
    if (parsed.choices && !parsed.categories) {
      parsed.categories = parsed.choices;
    } else if (parsed.categories && !parsed.choices) {
      parsed.choices = parsed.categories;
    }
    return parsed as ConsentRecord;
  } catch {
    return memoryConsent;
  }
}

export function writeConsent(
  sourceOrChoices: ConsentSource | { preferences: boolean; analytics?: boolean; marketing?: boolean; necessary?: boolean },
  maybeChoices?: { preferences: boolean; analytics?: boolean; marketing?: boolean }
): ConsentRecord {
  let source: ConsentSource = 'personalizado';
  let choicesPartial: { preferences?: boolean; analytics?: boolean; marketing?: boolean } = {};

  if (typeof sourceOrChoices === 'string') {
    source = sourceOrChoices;
    choicesPartial = maybeChoices || {};
  } else {
    choicesPartial = sourceOrChoices;
    if (choicesPartial.preferences && (!USES_ANALYTICS || choicesPartial.analytics) && (!USES_MARKETING || choicesPartial.marketing)) {
      source = 'aceitar-tudo';
    } else if (!choicesPartial.preferences && !choicesPartial.analytics && !choicesPartial.marketing) {
      source = 'recusar';
    } else {
      source = 'personalizado';
    }
  }

  const choices: ConsentChoices = {
    necessary: true,
    preferences: Boolean(choicesPartial.preferences),
  };
  if (USES_ANALYTICS) {
    choices.analytics = Boolean(choicesPartial.analytics);
  }
  if (USES_MARKETING) {
    choices.marketing = Boolean(choicesPartial.marketing);
  }

  const record: ConsentRecord = {
    v: 1,
    ts: new Date().toISOString(),
    policy: LEGAL.versao,
    source,
    choices,
    categories: choices,
  };

  memoryConsent = record;

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(record));
  } catch {
    // Keep in memory
  }

  // If preferences revoked, remove cw-theme immediately
  if (!choices.preferences) {
    try {
      localStorage.removeItem('cw-theme');
    } catch {
      //
    }
  } else {
    // If preferences granted, save current theme immediately
    try {
      const currentTheme = document.documentElement.dataset.theme || 'light';
      localStorage.setItem('cw-theme', currentTheme);
    } catch {
      //
    }
  }

  changeListeners.forEach((fn) => {
    try {
      fn(choices);
    } catch (e) {
      console.error(e);
    }
  });

  return record;
}

// Global CWConsent public API
declare global {
  interface Window {
    CWConsent?: {
      has: (category: string) => boolean;
      get: () => ConsentRecord | null;
      onChange: (callback: (choices: ConsentChoices) => void) => () => void;
      openPreferences: () => void;
      whenAllowed: (category: string, fn: () => void) => void;
    };
  }
}

if (typeof window !== 'undefined') {
  window.CWConsent = {
    has(category: string): boolean {
      if (category === 'necessary') return true;
      const rec = readStoredConsent();
      if (!rec || !rec.choices) return false;
      return Boolean((rec.choices as any)[category]);
    },
    get(): ConsentRecord | null {
      return readStoredConsent();
    },
    onChange(callback: (choices: ConsentChoices) => void): () => void {
      changeListeners.add(callback);
      return () => changeListeners.delete(callback);
    },
    openPreferences(): void {
      if (openPreferencesHandler) {
        openPreferencesHandler();
      }
    },
    whenAllowed(category: string, fn: () => void): void {
      if (window.CWConsent?.has(category)) {
        fn();
        return;
      }
      const unsub = window.CWConsent?.onChange((choices) => {
        if ((choices as any)[category]) {
          unsub?.();
          fn();
        }
      });
    },
  };
}
