import React, { useEffect, useRef, useState } from 'react';
import {
  GraduationCap,
  UserPlus,
  Award,
  Users,
  Rocket,
  Wrench,
  Headset,
  Clock,
  Network,
  Server,
  Palette,
  RefreshCw,
  Video,
  CalendarCheck,
  Trophy,
  FileCheck,
  ShieldCheck,
  BookOpen,
  LifeBuoy,
  Building2,
  Target,
  Lock,
  CheckCircle2,
} from 'lucide-react';
import {
  LEGAL,
  USES_ANALYTICS,
  USES_MARKETING,
  readStoredConsent,
  writeConsent,
  registerPreferencesOpener,
  ConsentRecord,
} from './consent';
import {
  PRIVACIDADE_SECTIONS,
  COOKIES_SECTIONS,
  PrivacidadeContent,
  CookiesContent,
} from './legalData';


// Demo scroll configuration (higher DEMO_SPEED means faster scroll)
const DEMO_SPEED = 340; // px / sec
const DEMO_MIN_DURATION = 6000; // 6s
const DEMO_MAX_DURATION = 18000; // 18s
const DEMO_REWIND_DURATION = 1200; // 1.2s scroll back
const DEMO_OPEN_TRIAL = true; // set to false to stop opening the trial modal at the end
const DEMO_OPEN_DELAY = 700; // ms to wait after stopping before opening it, so the FAQ is seen first
const easeInOutSine = (t: number) => -(Math.cos(Math.PI * t) - 1) / 2;

// Shared contact e-mail
const CONTACT_EMAIL = 'atendimento@corpwisegestao.com.br';

// Trial resources list
const TRIAL_CHIPS = [
  'Tema com a marca',
  'Salas BigBlueButton',
  'Gamificação Level Up!',
  'Controle de Attendance',
  'Certificados',
  'Suporte integrado',
  'Integração com RH / SSO',
];

// Single data source for FAQ questions and answers
interface FaqItem {
  q: string;
  a: string;
  slug: string;
}

const FAQ_DATA: FaqItem[] = [
  {
    q: 'O que é o Moodle?',
    a: 'O Moodle é uma plataforma de aprendizagem on-line que permite organizar cursos, disponibilizar materiais, propor atividades e acompanhar o progresso dos participantes. A CorpWise ajuda sua empresa a instalar, personalizar, hospedar ou receber suporte para essa plataforma.',
    slug: 'o-que-e-o-moodle',
  },
  {
    q: 'Qual plano devo escolher?',
    a: 'Se você ainda não tem o Moodle instalado e quer usar o servidor da sua empresa, escolha um plano de instalação. Se já tem um Moodle funcionando, escolha um plano de personalização. Se prefere não contratar nem administrar um servidor próprio, escolha um plano hospedado pela CorpWise.',
    slug: 'qual-plano-devo-escolher',
  },
  {
    q: 'Qual é a diferença entre instalar o Moodle e hospedar o Moodle?',
    a: 'Instalar é preparar a plataforma em um servidor. Nos planos de instalação, o servidor é fornecido pela sua empresa. Hospedar significa que a plataforma fica em uma infraestrutura fornecida pela CorpWise, conforme as condições do plano contratado.',
    slug: 'qual-e-a-diferenca-entre-instalar-o-moodle-e-hospedar-o-moodle',
  },
  {
    q: 'Preciso já ter um Moodle para contratar?',
    a: 'Não necessariamente. Os planos de instalação e hospedagem atendem empresas que ainda vão começar. Os planos de personalização são indicados para quem já tem o Moodle instalado e funcionando.',
    slug: 'preciso-ja-ter-um-moodle-para-contratar',
  },
  {
    q: 'O que está incluído na personalização?',
    a: 'A personalização pode incluir a aplicação da logo e das cores da empresa, ajustes na página inicial e configuração dos recursos ou plugins definidos para o projeto. O escopo é combinado antes do início do trabalho. Desenvolvimento de funcionalidades novas, integrações e plugins pagos podem exigir orçamento separado.',
    slug: 'o-que-esta-incluido-na-personalizacao',
  },
  {
    q: 'O plano inclui a criação dos cursos e dos materiais?',
    a: 'Não, a menos que isso esteja especificado na proposta. Os planos descritos são voltados à plataforma Moodle. Criação ou migração de cursos, produção de vídeos e materiais didáticos podem ser avaliadas e contratadas separadamente.',
    slug: 'o-plano-inclui-a-criacao-dos-cursos-e-dos-materiais',
  },
  {
    q: 'O que está incluído no suporte mensal?',
    a: 'O suporte é destinado aos responsáveis pelo Moodle na empresa e cobre orientações e questões técnicas relacionadas à plataforma, conforme o escopo contratado. Não inclui atendimento direto aos alunos, criação de cursos ou desenvolvimento de novos recursos, salvo quando isso estiver previsto na proposta.',
    slug: 'o-que-esta-incluido-no-suporte-mensal',
  },
  {
    q: 'Quanto custa o suporte?',
    a: 'O valor de referência do suporte mensal é R$ 1.500 nos planos que incluem esse serviço. Nos planos hospedados, a mensalidade total também deve indicar claramente o custo da hospedagem e o que ela contempla.',
    slug: 'quanto-custa-o-suporte',
  },
  {
    q: 'O que significa “sem suporte”?',
    a: 'Significa que o trabalho contratado cobre a instalação ou personalização descrita na proposta, mas não inclui acompanhamento técnico contínuo após a entrega. A manutenção e a administração do Moodle ficam sob responsabilidade da sua empresa.',
    slug: 'o-que-significa-sem-suporte',
  },
  {
    q: 'O plano hospedado inclui personalização?',
    a: 'Depende do plano. O plano hospedado com personalização inclui os ajustes combinados para o projeto. O plano hospedado sem personalização entrega o Moodle com configuração padrão. Personalizações solicitadas depois podem ser orçadas separadamente.',
    slug: 'o-plano-hospedado-inclui-personalizacao',
  },
  {
    q: 'Posso contratar novos recursos ou alterações depois?',
    a: 'Sim. Você pode solicitar novas personalizações, plugins ou integrações. A CorpWise avalia a compatibilidade e o esforço necessário e apresenta uma proposta antes de iniciar o trabalho.',
    slug: 'posso-contratar-novos-recursos-ou-alteracoes-depois',
  },
  {
    q: 'O Moodle tem custo de licença?',
    a: 'O Moodle LMS é um software de código aberto. Os valores dos planos correspondem aos serviços contratados, como instalação, personalização, suporte e hospedagem. Plugins ou serviços de terceiros podem ter custos próprios.',
    slug: 'o-moodle-tem-custo-de-licenca',
  },
];

// Color types and utilities
interface RGB {
  r: number;
  g: number;
  b: number;
}

function parseHex(hex: string): RGB {
  const h = hex.replace('#', '');
  return {
    r: parseInt(h.substring(0, 2), 16),
    g: parseInt(h.substring(2, 4), 16),
    b: parseInt(h.substring(4, 6), 16),
  };
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpRGB(c1: RGB, c2: RGB, t: number): RGB {
  return {
    r: Math.round(lerp(c1.r, c2.r, t)),
    g: Math.round(lerp(c1.g, c2.g, t)),
    b: Math.round(lerp(c1.b, c2.b, t)),
  };
}

function clamp(v: number, min = 0, max = 1): number {
  return Math.max(min, Math.min(max, v));
}

function getFaqTarget(): number {
  if (typeof document === 'undefined' || typeof window === 'undefined') return 0;
  const faqEl = document.getElementById('faq');
  const maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
  if (!faqEl) return maxScroll;
  const faqTop = faqEl.getBoundingClientRect().top + window.scrollY;
  const padTop = parseFloat(window.getComputedStyle(faqEl).paddingTop) || 0;
  return clamp(faqTop + padTop - 100, 0, maxScroll);
}

function smoothstep(v: number): number {
  const x = clamp(v, 0, 1);
  return x * x * (3 - 2 * x);
}

function smoothstepRange(min: number, max: number, v: number): number {
  const t = clamp((v - min) / (max - min), 0, 1);
  return t * t * (3 - 2 * t);
}

// Canvas Glow Palettes
const COL_OUTSIDE_LIGHT = parseHex('ffffff');
const COL_RIM_LIGHT = parseHex('5c93aa');
const COL_CORE_LIGHT = parseHex('164e63');

const COL_OUTSIDE_DARK = parseHex('0a1226');
const COL_RIM_DARK = parseHex('1b2a63');
const COL_CORE_DARK = parseHex('15607e');

// Letter reveal base colors
const COL_DARK_GHOST = parseHex('5c6f92');
const COL_DARK_ACCENT = parseHex('8fe6f4');
const COL_DARK_FINAL = parseHex('ffffff');

function getHeadlinePalette(isDark: boolean) {
  return {
    final: isDark ? parseHex('f2f6ff') : parseHex('ffffff'),
    accent: parseHex('8fe6f4'),
    ghost: isDark ? parseHex('0a1226') : parseHex('5c93aa'),
    brand: isDark ? parseHex('8aa4ff') : parseHex('8fe6f4'),
  };
}

function getStatementPalette(isDark: boolean) {
  return {
    final: isDark ? parseHex('f2f6ff') : parseHex('ffffff'),
    accent: parseHex('8fe6f4'),
    ghost: isDark ? parseHex('0f2a52') : parseHex('5c93aa'),
    brand: isDark ? parseHex('8aa4ff') : parseHex('8fe6f4'),
  };
}

// Scroll table keys
const SCROLL_KEYS = [
  { q: 0, tip: 0.72, half: 0.95, soft: 0.22 },
  { q: 0.03, tip: 0.74, half: 0.97, soft: 0.26 },
  { q: 0.08, tip: 0.80, half: 0.97, soft: 0.22 },
  { q: 0.18, tip: 0.88, half: 0.97, soft: 0.22 },
  { q: 0.40, tip: 0.98, half: 0.97, soft: 0.19 },
  { q: 0.66, tip: 1.05, half: 1.00, soft: 0.16 },
  { q: 0.87, tip: 1.05, half: 1.05, soft: 0.13 },
  { q: 1.15, tip: 1.10, half: 1.15, soft: 0.10 },
  { q: 1.43, tip: 1.30, half: 1.60, soft: 0.10 },
  { q: 1.80, tip: 2.40, half: 3.00, soft: 0.10 },
];

function getTargetBowl(q: number) {
  if (q <= SCROLL_KEYS[0].q) return { ...SCROLL_KEYS[0] };
  if (q >= SCROLL_KEYS[SCROLL_KEYS.length - 1].q) {
    return { ...SCROLL_KEYS[SCROLL_KEYS.length - 1] };
  }
  for (let i = 0; i < SCROLL_KEYS.length - 1; i++) {
    const k1 = SCROLL_KEYS[i];
    const k2 = SCROLL_KEYS[i + 1];
    if (q >= k1.q && q <= k2.q) {
      const u = (q - k1.q) / (k2.q - k1.q);
      return {
        q,
        tip: lerp(k1.tip, k2.tip, u),
        half: lerp(k1.half, k2.half, u),
        soft: lerp(k1.soft, k2.soft, u),
      };
    }
  }
  return { ...SCROLL_KEYS[0] };
}

// Letter reveal utilities
interface CharInfo {
  el: HTMLElement;
  isFlagged: boolean;
}

function splitText(el: HTMLElement): CharInfo[] {
  const originalHTML = el.innerHTML;
  const chars: CharInfo[] = [];
  const frag = document.createDocumentFragment();

  const parser = document.createElement('div');
  parser.innerHTML = originalHTML;

  function processNode(node: Node, currentFlagged = false) {
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent || '';
      const tokens = text.split(/(\s+)/);
      for (const token of tokens) {
        if (!token) continue;
        if (/^\s+$/.test(token)) {
          frag.appendChild(document.createTextNode(token));
        } else {
          const wordSpan = document.createElement('span');
          wordSpan.className = 'word-span';
          const characters = Array.from(token);
          for (const ch of characters) {
            const charSpan = document.createElement('span');
            charSpan.className = 'char-span';
            charSpan.textContent = ch;
            wordSpan.appendChild(charSpan);
            chars.push({ el: charSpan, isFlagged: currentFlagged });
          }
          frag.appendChild(wordSpan);
        }
      }
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const elem = node as HTMLElement;
      if (elem.tagName.toLowerCase() === 'br') {
        frag.appendChild(document.createElement('br'));
        frag.appendChild(document.createTextNode(' '));
      } else {
        const isFlag = currentFlagged || elem.classList.contains('hl');
        for (let i = 0; i < elem.childNodes.length; i++) {
          processNode(elem.childNodes[i], isFlag);
        }
      }
    }
  }

  for (let i = 0; i < parser.childNodes.length; i++) {
    processNode(parser.childNodes[i]);
  }

  el.innerHTML = '';
  el.appendChild(frag);
  return chars;
}

function paintChars(
  chars: CharInfo[],
  p: number,
  spread: number,
  finalCol: RGB,
  accentCol: RGB,
  ghostCol: RGB,
  brandCol: RGB = parseHex('5b7cf0')
) {
  const n = chars.length;
  if (n === 0) return;

  for (let i = 0; i < n; i++) {
    const item = chars[i];
    const t = clamp((p * (1 + spread) - i / n) / spread, 0, 1);
    let opacity = 0;
    let blur = 0;
    let c = ghostCol;

    const targetFinal = item.isFlagged ? brandCol : finalCol;

    if (t <= 0) {
      opacity = 0;
      c = ghostCol;
      blur = 8;
    } else if (t <= 0.35) {
      const k = t / 0.35;
      opacity = k;
      c = ghostCol;
      blur = lerp(8, 1.5, k);
    } else if (t <= 0.70) {
      const k = (t - 0.35) / 0.35;
      opacity = 1;
      c = lerpRGB(ghostCol, accentCol, k);
      blur = lerp(1.5, 0, k);
    } else {
      const k = (t - 0.70) / 0.30;
      opacity = 1;
      c = lerpRGB(accentCol, targetFinal, k);
      blur = 0;
    }

    item.el.style.opacity = opacity.toFixed(3);
    item.el.style.color = `rgb(${c.r}, ${c.g}, ${c.b})`;
    item.el.style.filter = blur > 0.05 ? `blur(${blur.toFixed(2)}px)` : 'none';
  }
}

// Navigation and Subpage types
interface NavRow {
  id: string;
  href: string;
  title: string;
  desc: string;
  topic: string;
  tag?: string;
  icon?: React.ReactNode;
}

interface NavTabItem {
  id: string;
  label: string;
  rows: NavRow[];
  featured: {
    title: string;
    text: string;
    button: string;
    topic: string;
  };
}

interface SubpageSection {
  id: string;
  title: string;
  desc: string;
  icon?: React.ReactNode;
  stepNum?: number;
  bullets: string[];
  meta?: string;
}

interface SubpageData {
  id: string;
  label: string;
  eyebrow: string;
  title: string;
  intro: string;
  sections: SubpageSection[];
}

const NAV_TABS: NavTabItem[] = [
  {
    id: 'servicos',
    label: 'Serviços',
    rows: [
      {
        id: 'integracao',
        href: '#/servicos/integracao',
        title: 'Integração com sistemas',
        desc: 'Conecte o Moodle ao seu RH, ERP e ferramentas internas.',
        topic: 'Integração com sistemas',
        icon: <Network size={20} strokeWidth={1.8} />,
      },
      {
        id: 'implantacao',
        href: '#/servicos/implantacao',
        title: 'Implantação e hospedagem',
        desc: 'Ambiente configurado, seguro e preparado para crescer.',
        topic: 'Implantação e hospedagem',
        icon: <Server size={20} strokeWidth={1.8} />,
      },
      {
        id: 'personalizacao',
        href: '#/servicos/personalizacao',
        title: 'Personalização visual',
        desc: 'Temas exclusivos com a identidade visual da sua marca.',
        topic: 'Personalização visual',
        icon: <Palette size={20} strokeWidth={1.8} />,
      },
      {
        id: 'migracao',
        href: '#/servicos/migracao',
        title: 'Migração e upgrade',
        desc: 'Atualização segura da sua versão do Moodle sem perda de dados.',
        topic: 'Migração e upgrade',
        icon: <RefreshCw size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Precisa de um projeto sob medida?',
      text: 'Avaliamos a infraestrutura e os fluxos da sua empresa para desenhar a solução ideal.',
      button: 'Falar com a CorpWise',
      topic: 'Serviços',
    },
  },
  {
    id: 'solucoes',
    label: 'Soluções',
    rows: [
      {
        id: 'treinamento-corporativo',
        href: '#/solucoes/treinamento-corporativo',
        title: 'Treinamento corporativo',
        desc: 'Trilhas e cursos para as equipes da sua empresa.',
        topic: 'Treinamento corporativo',
        icon: <GraduationCap size={20} strokeWidth={1.8} />,
      },
      {
        id: 'onboarding',
        href: '#/solucoes/onboarding',
        title: 'Onboarding de colaboradores',
        desc: 'Integração de quem entra, padronizada e acompanhada.',
        topic: 'Onboarding de colaboradores',
        icon: <UserPlus size={20} strokeWidth={1.8} />,
      },
      {
        id: 'compliance',
        href: '#/solucoes/compliance',
        title: 'Compliance e certificações',
        desc: 'Treinamentos obrigatórios com prazo, lembrete e certificado.',
        topic: 'Compliance e certificações',
        icon: <Award size={20} strokeWidth={1.8} />,
      },
      {
        id: 'clientes-parceiros',
        href: '#/solucoes/clientes-parceiros',
        title: 'Treinamento de clientes e parceiros',
        desc: 'Um Moodle para quem está fora da empresa também.',
        topic: 'Treinamento de clientes e parceiros',
        icon: <Users size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Seu caso é diferente?',
      text: 'Adaptamos o Moodle ao tipo de treinamento que a sua empresa faz.',
      button: 'Falar com a CorpWise',
      topic: 'Soluções',
    },
  },
  {
    id: 'plugins',
    label: 'Plugins',
    rows: [
      {
        id: 'bigbluebutton',
        href: '#/plugins/bigbluebutton',
        title: 'BigBlueButton',
        desc: 'Salas de aula virtuais e videoconferências ao vivo integradas.',
        topic: 'BigBlueButton',
        icon: <Video size={20} strokeWidth={1.8} />,
      },
      {
        id: 'attendance',
        href: '#/plugins/attendance',
        title: 'Attendance',
        desc: 'Controle automatizado de presença e frequência em tempo real.',
        topic: 'Attendance',
        icon: <CalendarCheck size={20} strokeWidth={1.8} />,
      },
      {
        id: 'level-up',
        href: '#/plugins/level-up',
        title: 'Level Up!',
        desc: 'Gamificação com níveis, pontos e recompensas para engajar equipes.',
        topic: 'Level Up!',
        icon: <Trophy size={20} strokeWidth={1.8} />,
      },
      {
        id: 'boost-union',
        href: '#/plugins/boost-union',
        title: 'Boost Union & Certificados',
        desc: 'Temas modernos com Boost Union e emissão de certificados válidos.',
        topic: 'Boost Union & Certificados',
        icon: <FileCheck size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Quer um plugin específico?',
      text: 'Homologamos, instalamos e configuramos qualquer plugin do ecossistema Moodle.',
      button: 'Consultar plugins',
      topic: 'Plugins',
    },
  },
  {
    id: 'como-funciona',
    label: 'Como funciona',
    rows: [
      {
        id: 'diagnostico',
        href: '#/como-funciona/diagnostico',
        title: 'Diagnóstico',
        desc: 'Entendemos o seu treinamento, o seu público e os sistemas que precisam se conectar.',
        topic: 'Diagnóstico',
      },
      {
        id: 'implantacao-configuracao',
        href: '#/como-funciona/implantacao-configuracao',
        title: 'Implantação',
        desc: 'Configuramos, personalizamos e integramos o Moodle com a sua marca.',
        topic: 'Implantação',
      },
      {
        id: 'treinamento-equipe',
        href: '#/como-funciona/treinamento-equipe',
        title: 'Treinamento da equipe',
        desc: 'Mostramos a administradores e instrutores como usar a plataforma.',
        topic: 'Treinamento da equipe',
      },
      {
        id: 'suporte-continuo',
        href: '#/como-funciona/suporte-continuo',
        title: 'Suporte contínuo',
        desc: 'Acompanhamos, atualizamos e resolvemos o que aparecer.',
        topic: 'Suporte contínuo',
      },
    ],
    featured: {
      title: 'Comece pelo diagnóstico',
      text: 'Conte o seu cenário e dizemos o que faz sentido para o seu caso.',
      button: 'Agendar conversa',
      topic: 'Diagnóstico',
    },
  },
  {
    id: 'suporte',
    label: 'Suporte',
    rows: [
      {
        id: 'suporte-integrado',
        href: '#/suporte/suporte-integrado',
        title: 'Suporte integrado',
        desc: 'Atendimento dentro do próprio Moodle, com resposta mais rápida.',
        topic: 'Suporte integrado',
        tag: 'Custo adicional',
        icon: <Headset size={20} strokeWidth={1.8} />,
      },
      {
        id: 'sustentacao-monitoramento',
        href: '#/suporte/sustentacao-monitoramento',
        title: 'Sustentação e monitoramento',
        desc: 'Rotinas de segurança, backups periódicos e atualizações contínuas.',
        topic: 'Sustentação e monitoramento',
        icon: <ShieldCheck size={20} strokeWidth={1.8} />,
      },
      {
        id: 'atendimento-comercial',
        href: '#/suporte/atendimento-comercial',
        title: 'Atendimento em horário comercial',
        desc: 'Equipe técnica dedicada para tirar dúvidas e corrigir problemas.',
        topic: 'Atendimento em horário comercial',
        icon: <LifeBuoy size={20} strokeWidth={1.8} />,
      },
      {
        id: 'treinamento-administradores',
        href: '#/suporte/treinamento-administradores',
        title: 'Treinamento de administradores',
        desc: 'Capacitação prática para a sua equipe gerenciar o Moodle com autonomia.',
        topic: 'Treinamento de administradores',
        icon: <BookOpen size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Ferramenta de suporte integrada',
      text: 'Atendimento ao aluno e ao gestor dentro do próprio Moodle, com resposta ágil.',
      button: 'Conhecer suporte',
      topic: 'Suporte',
    },
  },
  {
    id: 'planos',
    label: 'Planos',
    rows: [
      {
        id: 'projeto-implantacao',
        href: '#/planos/projeto-implantacao',
        title: 'Implantação',
        desc: 'Projeto fechado: instalação, tema, plugins e integrações.',
        topic: 'Implantação',
        icon: <Rocket size={20} strokeWidth={1.8} />,
      },
      {
        id: 'manutencao-mensal',
        href: '#/planos/manutencao-mensal',
        title: 'Manutenção mensal',
        desc: 'Atualizações, backups e suporte em horário comercial.',
        topic: 'Manutenção mensal',
        icon: <Wrench size={20} strokeWidth={1.8} />,
      },
      {
        id: 'suporte-integrado-plano',
        href: '#/planos/suporte-integrado-plano',
        title: 'Suporte integrado',
        desc: 'Atendimento dentro do próprio Moodle, com resposta mais rápida.',
        topic: 'Suporte integrado',
        tag: 'Custo adicional',
        icon: <Headset size={20} strokeWidth={1.8} />,
      },
      {
        id: 'horas-avulsas',
        href: '#/planos/horas-avulsas',
        title: 'Horas avulsas',
        desc: 'Desenvolvimento sob medida e pedidos fora do pacote.',
        topic: 'Horas avulsas',
        icon: <Clock size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Orçamento sob medida',
      text: 'O valor depende do porte do seu Moodle. Conte o seu cenário e enviamos uma proposta.',
      button: 'Pedir orçamento',
      topic: 'Orçamento',
    },
  },
  {
    id: 'empresa',
    label: 'Empresa',
    rows: [
      {
        id: 'sobre-nos',
        href: '#/empresa/sobre-nos',
        title: 'Sobre a CorpWise',
        desc: 'Especialistas focados exclusivamente em projetos empresariais com Moodle.',
        topic: 'Sobre a CorpWise',
        icon: <Building2 size={20} strokeWidth={1.8} />,
      },
      {
        id: 'metodo-corpwise',
        href: '#/empresa/metodo-corpwise',
        title: 'Nosso método',
        desc: 'Processo estruturado de diagnóstico, implementação e acompanhamento contínuo.',
        topic: 'Nosso método',
        icon: <Target size={20} strokeWidth={1.8} />,
      },
      {
        id: 'seguranca-lgpd',
        href: '#/empresa/seguranca-lgpd',
        title: 'Segurança e conformidade',
        desc: 'Moodle alinhado às diretrizes de governança e LGPD da sua empresa.',
        topic: 'Segurança e conformidade',
        icon: <Lock size={20} strokeWidth={1.8} />,
      },
      {
        id: 'compromisso-resultados',
        href: '#/empresa/compromisso-resultados',
        title: 'Cases e clientes',
        desc: 'Empresas que confiam na nossa consultoria para capacitar seus times.',
        topic: 'Cases e clientes',
        icon: <CheckCircle2 size={20} strokeWidth={1.8} />,
      },
    ],
    featured: {
      title: 'Parceiro estratégico em Moodle',
      text: 'Não somos uma empresa de IA. Cuidamos do seu Moodle para sua empresa crescer.',
      button: 'Falar com a CorpWise',
      topic: 'Empresa',
    },
  },
];

const SUBPAGES_DATA: Record<string, SubpageData> = {
  servicos: {
    id: 'servicos',
    label: 'Serviços',
    eyebrow: 'SERVIÇOS',
    title: 'Integração, implantação e personalização de Moodle',
    intro:
      'Cuidamos de toda a infraestrutura técnica, temas visuais e conexões do Moodle para que sua empresa foque exclusivamente no desenvolvimento e treinamento das suas equipes.',
    sections: [
      {
        id: 'integracao',
        title: 'Integração com sistemas',
        desc: 'Conecte o Moodle ao seu RH, ERP, CRM e ferramentas internas sem necessidade de planilhas manuais ou retrabalho.',
        icon: <Network size={24} strokeWidth={1.8} />,
        bullets: [
          'Sincronização automática de colaboradores, filiais e cargos via API',
          'Matrículas automáticas e dinâmicas baseadas em regras de negócio',
          'Envio de notas, presenças e histórico para o RH ou LMS legado',
          'Login único (Single Sign-On - SSO) com Azure AD, Google Workspace ou SAML',
        ],
        meta: 'Para quem precisa eliminar retrabalho manual',
      },
      {
        id: 'implantacao',
        title: 'Implantação e hospedagem em nuvem',
        desc: 'Ambiente configurado em infraestrutura de nuvem segura, escalável e otimizada para alto tráfego simultâneo.',
        icon: <Server size={24} strokeWidth={1.8} />,
        bullets: [
          'Servidores dedicados com redundância e alta disponibilidade',
          'Otimização profunda de cache Redis, PHP e banco de dados',
          'Configuração de certificado SSL e domínio corporativo próprio',
          'Rotina de backups diários automatizados em repositórios externos',
        ],
        meta: 'Ideal para empresas iniciando ou trocando de servidor',
      },
      {
        id: 'personalizacao',
        title: 'Personalização visual e temas exclusivos',
        desc: 'Temas modernos e intuitivos alinhados à identidade visual da sua marca, superando a aparência acadêmica antiga.',
        icon: <Palette size={24} strokeWidth={1.8} />,
        bullets: [
          'Layout limpo focado na experiência de aprendizagem corporativa',
          'Adaptação completa de cores, tipografia, logotipos e iconografia',
          'Design 100% responsivo para computadores, tablets e smartphones',
          'Certificados personalizados com código de validação pública e assinatura',
        ],
        meta: 'Para fortalecer a marca e o engajamento dos alunos',
      },
      {
        id: 'migracao',
        title: 'Migração e upgrade de versão',
        desc: 'Atualização segura da sua versão do Moodle para as versões LTS mais recentes, sem risco de perda de dados.',
        icon: <RefreshCw size={24} strokeWidth={1.8} />,
        bullets: [
          'Homologação prévia de dados e plugins em ambiente de teste',
          'Migração de banco de dados e arquivos com janela mínima de indisponibilidade',
          'Auditoria e correção de compatibilidade de temas e extensões legadas',
          'Documentação técnica e treinamento sobre as melhorias da nova versão',
        ],
        meta: 'Para ambientes defasados ou com lentidão',
      },
    ],
  },
  solucoes: {
    id: 'solucoes',
    label: 'Soluções',
    eyebrow: 'SOLUÇÕES',
    title: 'Soluções sob medida para cada desafio corporativo',
    intro:
      'Estruture programas de capacitação consistentes para diferentes públicos da sua empresa, de novos contratados a parceiros comerciais.',
    sections: [
      {
        id: 'treinamento-corporativo',
        title: 'Treinamento corporativo contínuo',
        desc: 'Trilhas de capacitação estruturadas para desenvolver competências estratégicas em todas as áreas da empresa.',
        icon: <GraduationCap size={24} strokeWidth={1.8} />,
        bullets: [
          'Estruturação de cursos por departamento, nível hierárquico e competência',
          'Suporte a múltiplos formatos: SCORM, vídeos, podcasts e questionários',
          'Painéis analíticos de progresso para lideranças e gestores de RH',
          'Certificados automáticos emitidos ao atingir nota e presença mínimas',
        ],
        meta: 'Focado no aumento de produtividade e retenção',
      },
      {
        id: 'onboarding',
        title: 'Onboarding acelerado de colaboradores',
        desc: 'Reduza o tempo de integração e garanta que novos contratados assimilem a cultura e os processos rapidamente.',
        icon: <UserPlus size={24} strokeWidth={1.8} />,
        bullets: [
          'Acesso imediato no primeiro dia com trilhas de boas-vindas',
          'Conteúdos padronizados sobre cultura, políticas e ferramentas internas',
          'Checklists interativos e avaliações práticas de assimilação',
          'Acompanhamento do período de experiência em relatórios claros',
        ],
        meta: 'Redução de tempo até a plena produtividade',
      },
      {
        id: 'compliance',
        title: 'Compliance e certificações regulatórias',
        desc: 'Gestão confiável de treinamentos obrigatórios (NRs, segurança da informação, código de conduta e LGPD).',
        icon: <Award size={24} strokeWidth={1.8} />,
        bullets: [
          'Lembretes automáticos e notificações de prazos de reciclagem',
          'Trilhas auditáveis com histórico de tentativas e registro de IP',
          'Emissão de certificados digitais rastreáveis com QR code',
          'Relatórios exportáveis com comprovação jurídica para auditorias',
        ],
        meta: 'Segurança jurídica e conformidade regulatória',
      },
      {
        id: 'clientes-parceiros',
        title: 'Treinamento de parceiros e clientes',
        desc: 'Capacite sua rede externa de distribuidores, franqueados e clientes com a mesma excelência do time interno.',
        icon: <Users size={24} strokeWidth={1.8} />,
        bullets: [
          'Ambientes segmentados por grupo ou filial com autonomia de gestão',
          'Certificação de integradores e equipes de suporte parceiras',
          'Materiais e manuais centralizados em um único portal oficial',
          'Métricas de engajamento e conclusão por empresa conveniada',
        ],
        meta: 'Escala para canais externos de distribuição',
      },
    ],
  },
  plugins: {
    id: 'plugins',
    label: 'Plugins',
    eyebrow: 'PLUGINS HOMOLOGADOS',
    title: 'Os melhores plugins do ecossistema Moodle para a sua empresa',
    intro:
      'Testamos, homologamos e mantemos os plugins mais consolidados do Moodle para transformar sua plataforma em uma experiência interativa e produtiva.',
    sections: [
      {
        id: 'bigbluebutton',
        title: 'BigBlueButton (Aulas e Reuniões ao Vivo)',
        desc: 'Salas de videoconferência de alta qualidade totalmente integradas à interface do Moodle, sem softwares externos.',
        icon: <Video size={24} strokeWidth={1.8} />,
        bullets: [
          'Compartilhamento de apresentações, telas e anotações conjuntas',
          'Gravação automática direto no curso para revisão dos alunos',
          'Salas temáticas de apoio (breakout rooms) para trabalhos em grupo',
          'Controle avançado de microfones, chats privados e enquetes rápidas',
        ],
        meta: 'Videoconferência interativa nativa',
      },
      {
        id: 'attendance',
        title: 'Attendance (Controle de Frequência)',
        desc: 'Gestão simplificada e automatizada de presença em encontros síncronos e aulas presenciais.',
        icon: <CalendarCheck size={24} strokeWidth={1.8} />,
        bullets: [
          'Marcação via QR Code dinâmico ou senha temporária em sala',
          'Cálculo automático de porcentagem de assiduidade para aprovação',
          'Exportação de planilhas detalhadas para controle do RH',
          'Gatilho direto para liberação de avaliações finais e certificados',
        ],
        meta: 'Assiduidade precisa e automatizada',
      },
      {
        id: 'level-up',
        title: 'Level Up! (Gamificação e Engajamento)',
        desc: 'Mecânicas comprovadas de jogos para aumentar o interesse, engajamento e a taxa de conclusão dos cursos.',
        icon: <Trophy size={24} strokeWidth={1.8} />,
        bullets: [
          'Pontos de experiência (XP) concedidos a cada atividade cumprida',
          'Barras visuais de nível no perfil do usuário e no painel inicial',
          'Medalhas personalizadas para conquistas e desafios concluídos',
          'Rankings amigáveis entre colaboradores do mesmo departamento',
        ],
        meta: 'Engajamento e retenção de alunos',
      },
      {
        id: 'boost-union',
        title: 'Boost Union & Custom Certificate',
        desc: 'O tema mais moderno e flexível do Moodle combinado com geração profissional de certificados oficiais.',
        icon: <FileCheck size={24} strokeWidth={1.8} />,
        bullets: [
          'Navegação limpa e moderna sem distrações ou sobrecarga visual',
          'Banners informativos e alertas direcionados no topo da página',
          'Certificados personalizados em alta resolução com assinatura digital',
          'Página de validação de código aberta para verificação de autenticidade',
        ],
        meta: 'Design contemporâneo e credibilidade',
      },
    ],
  },
  'como-funciona': {
    id: 'como-funciona',
    label: 'Como funciona',
    eyebrow: 'METODOLOGIA',
    title: 'Do diagnóstico ao suporte: nosso método passo a passo',
    intro:
      'Uma metodologia ágil e comprovada para implementar, modernizar e sustentar o Moodle da sua empresa sem sobrecarregar sua equipe técnica.',
    sections: [
      {
        id: 'diagnostico',
        stepNum: 1,
        title: 'Diagnóstico e Mapeamento',
        desc: 'Compreendemos o modelo de treinamento da sua empresa, o perfil dos alunos e as integrações necessárias.',
        bullets: [
          'Reunião técnica de levantamento de escopo e fluxos operacionais',
          'Avaliação da infraestrutura atual ou dimensionamento de nova nuvem',
          'Mapeamento dos sistemas de RH/ERP que alimentarão o Moodle',
          'Apresentação de proposta técnica clara com cronograma de entregas',
        ],
        meta: 'Etapa 1 · Planejamento e alinhamento',
      },
      {
        id: 'implantacao-configuracao',
        stepNum: 2,
        title: 'Configuração e Desenvolvimento',
        desc: 'Preparamos os servidores, personalizamos o tema corporativo e instalamos os plugins aprovados.',
        bullets: [
          'Provisionamento seguro em servidores de alto desempenho',
          'Aplicação do tema com logotipo, paleta de cores e tipografia da marca',
          'Instalação e homologação dos plugins em ambiente de homologação',
          'Testes rigorosos de carga e segurança antes do lançamento',
        ],
        meta: 'Etapa 2 · Construção e validação',
      },
      {
        id: 'treinamento-equipe',
        stepNum: 3,
        title: 'Capacitação Prática da Equipe',
        desc: 'Ensinamos seus gestores e instrutores a utilizarem todos os recursos da plataforma com total autonomia.',
        bullets: [
          'Treinamento prático e gravado para consulta da equipe a qualquer momento',
          'Guia passo a passo para criação de cursos, módulos e questionários',
          'Instruções detalhadas para extração de relatórios e controle de notas',
          'Período acompanhado de testes com apoio de nossos especialistas',
        ],
        meta: 'Etapa 3 · Transferência de autonomia',
      },
      {
        id: 'suporte-continuo',
        stepNum: 4,
        title: 'Sustentação e Suporte Contínuo',
        desc: 'Mantemos sua plataforma atualizada, segura e monitorada, garantindo que o treinamento dos colaboradores nunca pare.',
        bullets: [
          'Monitoramento contínuo de disponibilidade e desempenho',
          'Backups automatizados e aplicação de patches de segurança',
          'Canal direto para suporte técnico com especialistas seniores',
          'Opção de ferramenta de atendimento integrada dentro do próprio Moodle',
        ],
        meta: 'Etapa 4 · Parceria de longo prazo',
      },
    ],
  },
  suporte: {
    id: 'suporte',
    label: 'Suporte',
    eyebrow: 'SUPORTE TÉCNICO',
    title: 'Sustentação especializada para o seu Moodle nunca parar',
    intro:
      'Tenha a tranquilidade de contar com uma equipe de especialistas cuidando de atualizações, segurança e resolução de chamados técnicos.',
    sections: [
      {
        id: 'suporte-integrado',
        title: 'Ferramenta de Suporte Integrada ao Moodle',
        desc: 'Atendimento ágil para alunos e instrutores direto na interface do Moodle, sem precisar trocar de tela.',
        icon: <Headset size={24} strokeWidth={1.8} />,
        bullets: [
          'Abertura de chamados com um clique dentro do próprio curso',
          'Histórico unificado de conversas vinculado ao perfil do colaborador',
          'Redução comprovada no tempo médio de resposta e resolução',
          'Relatórios mensais dos tópicos e dúvidas mais frequentes',
        ],
        meta: 'Ferramenta opcional · Custo adicional',
      },
      {
        id: 'sustentacao-monitoramento',
        title: 'Sustentação de infraestrutura e backups',
        desc: 'Monitoramento preventivo para garantir máxima velocidade, estabilidade e proteção contra incidentes.',
        icon: <ShieldCheck size={24} strokeWidth={1.8} />,
        bullets: [
          'Supervisão em tempo real do consumo de memória, CPU e disco',
          'Rotinas diárias de backup com armazenamento criptografado externo',
          'Aplicação imediata de correções de vulnerabilidades e patches oficiais',
          'Otimização contínua de consultas ao banco de dados PostgreSQL/MySQL',
        ],
        meta: 'Segurança e disponibilidade contínua',
      },
      {
        id: 'atendimento-comercial',
        title: 'Atendimento em horário comercial',
        desc: 'Equipe técnica disponível para orientar os administradores e solucionar ocorrências do dia a dia.',
        icon: <LifeBuoy size={24} strokeWidth={1.8} />,
        bullets: [
          'Canais diretos de atendimento com especialistas Moodle',
          'SLA garantido para atendimento e priorização de chamados urgentes',
          'Apoio na configuração de novas turmas, cursos e permissões',
          'Resolução ágil de falhas de matrícula ou sincronização de dados',
        ],
        meta: 'Suporte consultivo e humanizado',
      },
      {
        id: 'treinamento-administradores',
        title: 'Capacitação contínua de administradores',
        desc: 'Apoio consultivo contínuo para sua equipe dominar as funcionalidades mais avançadas do Moodle.',
        icon: <BookOpen size={24} strokeWidth={1.8} />,
        bullets: [
          'Sessões periódicas de alinhamento e apresentação de novidades',
          'Consultoria para estruturação de novas trilhas de capacitação',
          'Orientações sobre melhores práticas de design instrucional no Moodle',
          'Apoio técnico na integração de novos conteúdos SCORM ou H5P',
        ],
        meta: 'Autonomia e evolução do time',
      },
    ],
  },
  planos: {
    id: 'planos',
    label: 'Planos',
    eyebrow: 'PLANOS E CONTRATAÇÃO',
    title: 'Formatos flexíveis de investimento para cada fase do seu projeto',
    intro:
      'Escolha entre implantação por projeto fechado, contratos mensais de manutenção contínua ou pacotes flexíveis de horas técnicas.',
    sections: [
      {
        id: 'projeto-implantacao',
        title: 'Projeto de Implantação e Modernização',
        desc: 'Ideal para empresas que desejam lançar um novo Moodle corporativo ou reformular por completo um ambiente antigo.',
        icon: <Rocket size={24} strokeWidth={1.8} />,
        bullets: [
          'Instalação do Moodle mais recente em nuvem de alta capacidade',
          'Tema personalizado com a identidade visual completa da sua empresa',
          'Configuração dos 4 plugins essenciais homologados',
          'Treinamento prático da equipe e entrega com garantia técnica',
        ],
        meta: 'Escopo fechado · Entrega rápida e garantida',
      },
      {
        id: 'manutencao-mensal',
        title: 'Manutenção e Sustentação Mensal',
        desc: 'Contrato contínuo para manter sua plataforma sempre veloz, atualizada e com suporte técnico à disposição.',
        icon: <Wrench size={24} strokeWidth={1.8} />,
        bullets: [
          'Monitoramento 24/7 de infraestrutura e prevenção de instabilidade',
          'Backups automáticos diários em servidores externos redundantes',
          'Atendimento de suporte a administradores em horário comercial',
          'Horas inclusas no mês para pequenos ajustes, relatórios ou dúvidas',
        ],
        meta: 'Recorrência mensal · Tranquilidade técnica',
      },
      {
        id: 'suporte-integrado-plano',
        title: 'Suporte Integrado (Add-on opcional)',
        desc: 'Módulo especial de suporte direto dentro do Moodle para empresas que desejam atender seus alunos com rapidez.',
        icon: <Headset size={24} strokeWidth={1.8} />,
        bullets: [
          'Widget exclusivo posicionado no rodapé ou menu do aluno',
          'Fila de atendimento organizada e distribuída para a equipe de suporte',
          'Métricas de tempo de resposta e satisfação dos colaboradores',
          'Integração nativa sem necessidade de sistemas de helpdesk externos',
        ],
        meta: 'Opcional · Cobrado por volume de usuários ou ambiente',
      },
      {
        id: 'horas-avulsas',
        title: 'Banco de Horas Sob Medida',
        desc: 'Pacotes flexíveis de horas técnicas para demandas pontuais, novos desenvolvimentos e integrações customizadas.',
        icon: <Clock size={24} strokeWidth={1.8} />,
        bullets: [
          'Desenvolvimento de integrações via Web Services com APIs internas',
          'Criação de consultas avançadas de relatórios SQL customizados',
          'Auditoria técnica de segurança e desempenho de instâncias existentes',
          'Sem mensalidade fixa: utilize as horas conforme sua necessidade',
        ],
        meta: 'Flexibilidade total · Sem prazo de expiração curto',
      },
    ],
  },
  empresa: {
    id: 'empresa',
    label: 'Empresa',
    eyebrow: 'SOBRE A CORPWISE',
    title: 'Especialistas dedicados exclusivamente ao sucesso do seu Moodle',
    intro:
      'Unimos sólida experiência em tecnologia e infraestrutura com foco prático nas necessidades reais de treinamento corporativo.',
    sections: [
      {
        id: 'sobre-nos',
        title: 'Especialistas em Moodle para empresas',
        desc: 'A CorpWise não é uma empresa de inteligência artificial nem uma agência generalista. Nosso compromisso é o ecossistema Moodle corporativo.',
        icon: <Building2 size={24} strokeWidth={1.8} />,
        bullets: [
          'Anos de atuação prática com grandes ambientes corporativos Moodle',
          'Conhecimento aprofundado do código-fonte e dos padrões oficiais da comunidade',
          'Atendimento próximo com foco em resolver o problema sem enrolação',
          'Defesa do código aberto: sua empresa é proprietária de todos os seus dados e cursos',
        ],
        meta: 'Especialização técnica genuína',
      },
      {
        id: 'metodo-corpwise',
        title: 'Metodologia de trabalho comprovada',
        desc: 'Garantimos previsibilidade e estabilidade por meio de processos padronizados de homologação e implantação.',
        icon: <Target size={24} strokeWidth={1.8} />,
        bullets: [
          'Ambiente de teste (homologação) antes de qualquer alteração em produção',
          'Documentação técnica clara de todas as configurações e customizações realizadas',
          'Comunicação objetiva e ágil com canais diretos aos engenheiros responsáveis',
          'Relatórios periódicos de integridade e recomendações de evolução',
        ],
        meta: 'Previsibilidade e segurança',
      },
      {
        id: 'seguranca-lgpd',
        title: 'Segurança da informação e conformidade com a LGPD',
        desc: 'Os dados dos seus colaboradores e os conteúdos corporativos são protegidos com as melhores práticas de governança.',
        icon: <Lock size={24} strokeWidth={1.8} />,
        bullets: [
          'Termos de consentimento e políticas de retenção configuradas no Moodle',
          'Autenticação multifator (MFA) e permissões por privilégio mínimo',
          'Criptografia de dados sensíveis e backups em conformidade com as normas',
          'Logs de auditoria preservados para auditorias de conformidade',
        ],
        meta: 'Governança e conformidade rigorosa',
      },
      {
        id: 'compromisso-resultados',
        title: 'Resultados que impactam seu treinamento',
        desc: 'Trabalhamos para que sua plataforma seja valorizada pelos colaboradores e forneça dados concretos para a gestão.',
        icon: <CheckCircle2 size={24} strokeWidth={1.8} />,
        bullets: [
          'Taxas de engajamento e conclusão expressivamente mais altas',
          'Zero interrupções ou lentidões nos momentos críticos de avaliação',
          'Economia comprovada de tempo na gestão de matrículas e certificados',
          'Parceria duradoura para o crescimento contínuo da sua universidade corporativa',
        ],
        meta: 'Impacto mensurável no negócio',
      },
    ],
  },
};

function parseRoute(hash: string): { path: string; section: string | null } {
  const clean = hash.replace(/^#\/?/, '').trim();
  if (!clean) return { path: 'home', section: null };
  const parts = clean.split('/').filter(Boolean);
  const path = parts[0] || 'home';
  const section = parts[1] || null;
  const validPaths = [
    'servicos',
    'solucoes',
    'plugins',
    'como-funciona',
    'suporte',
    'planos',
    'empresa',
    'duvidas',
    'privacidade',
    'cookies',
  ];
  if (!validPaths.includes(path)) {
    return { path: 'home', section: null };
  }
  return { path, section };
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const navRef = useRef<HTMLElement | null>(null);
  const h1Ref = useRef<HTMLHeadingElement | null>(null);
  const stmtRef = useRef<HTMLParagraphElement | null>(null);
  const splitRef = useRef<HTMLElement | null>(null);
  const h2Ref = useRef<HTMLHeadingElement | null>(null);
  const rowRef = useRef<HTMLDivElement | null>(null);
  const shipRef = useRef<HTMLImageElement | null>(null);

  const dialogRef = useRef<HTMLDialogElement | null>(null);
  const openerRef = useRef<HTMLElement | null>(null);

  const trialDialogRef = useRef<HTMLDialogElement | null>(null);
  const trialOpenerRef = useRef<HTMLElement | null>(null);

  const cookiePrefsDialogRef = useRef<HTMLDialogElement | null>(null);
  const cookiePrefsOpenerRef = useRef<HTMLElement | null>(null);

  // Cookie banner & consent state
  const [showCookieBanner, setShowCookieBanner] = useState(false);
  const [storedConsent, setStoredConsent] = useState<ConsentRecord | null>(() => readStoredConsent());
  const [prefsAllowed, setPrefsAllowed] = useState(false);
  const [prefsFeedback, setPrefsFeedback] = useState('');

  // Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof document !== 'undefined') {
      return (document.documentElement.dataset.theme as 'light' | 'dark') || 'light';
    }
    return 'light';
  });
  const themeRef = useRef<'light' | 'dark'>(theme);
  themeRef.current = theme;

  // Routing state
  const [currentRoute, setCurrentRoute] = useState<{ path: string; section: string | null }>(() =>
    typeof window !== 'undefined' ? parseRoute(window.location.hash) : { path: 'home', section: null }
  );
  const currentRouteRef = useRef(currentRoute);
  currentRouteRef.current = currentRoute;

  const [activeSectionId, setActiveSectionId] = useState<string | null>(null);
  const [openFaqSlug, setOpenFaqSlug] = useState<string | null>(null);


  // Demo state
  const [isDemoRunning, setIsDemoRunning] = useState(false);
  const [demoStatus, setDemoStatus] = useState<'idle' | 'running' | 'finished'>('idle');
  const demoRafRef = useRef<number | null>(null);
  const demoTrialTimerRef = useRef<NodeJS.Timeout | null>(null);
  const demoStartTimeRef = useRef<number>(0);
  const demoExpectedScrollRef = useRef<number>(0);
  const isDemoRunningRef = useRef(false);
  isDemoRunningRef.current = isDemoRunning;

  // Subpage H1 ref for letter reveal
  const subpageH1Ref = useRef<HTMLHeadingElement | null>(null);

  // Contact modal state
  const [formState, setFormState] = useState({
    nome: '',
    email: '',
    empresa: '',
    mensagem: '',
  });
  const [touchedFields, setTouchedFields] = useState<Record<string, boolean>>({});
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [popupBlockedUrl, setPopupBlockedUrl] = useState<string | null>(null);

  // Trial / Access request modal state
  const [trialFormState, setTrialFormState] = useState({
    nome: '',
    email: '',
    empresa: '',
    porte: '',
  });
  const [selectedChips, setSelectedChips] = useState<string[]>([]);
  const [trialTouchedFields, setTrialTouchedFields] = useState<Record<string, boolean>>({});
  const [trialSubmitSuccess, setTrialSubmitSuccess] = useState(false);
  const [trialPopupBlockedUrl, setTrialPopupBlockedUrl] = useState<string | null>(null);

  const [activeNavTab, setActiveNavTab] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mobileAccordionOpen, setMobileAccordionOpen] = useState<string | null>('servicos');
  const navCloseTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Store references to parsed character spans & progress for immediate theme repainting
  const h1CharsRef = useRef<CharInfo[]>([]);
  const stmtCharsRef = useRef<CharInfo[]>([]);
  const h2CharsRef = useRef<CharInfo[]>([]);
  const subH1CharsRef = useRef<CharInfo[]>([]);

  const h1ProgressRef = useRef(0);
  const stmtProgressRef = useRef(0);
  const h2ProgressRef = useRef(0);
  const subH1ProgressRef = useRef(0);

  // Repaint all visible letter reveals when theme changes
  const repaintAllLetters = (currentTheme: 'light' | 'dark') => {
    const isDark = currentTheme === 'dark';
    const palH1 = getHeadlinePalette(isDark);
    const palStmt = getStatementPalette(isDark);

    if (h1CharsRef.current.length > 0) {
      paintChars(h1CharsRef.current, h1ProgressRef.current, 0.35, palH1.final, palH1.accent, palH1.ghost, palH1.brand);
    }
    if (stmtCharsRef.current.length > 0) {
      paintChars(stmtCharsRef.current, stmtProgressRef.current, 0.16, palStmt.final, palStmt.accent, palStmt.ghost, palStmt.brand);
    }
    if (subH1CharsRef.current.length > 0) {
      paintChars(subH1CharsRef.current, subH1ProgressRef.current, 0.35, palH1.final, palH1.accent, palH1.ghost, palH1.brand);
    }
    if (h2CharsRef.current.length > 0) {
      paintChars(h2CharsRef.current, h2ProgressRef.current, 0.35, COL_DARK_FINAL, COL_DARK_ACCENT, COL_DARK_GHOST);
    }
  };

  // Toggle Theme handler
  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    themeRef.current = newTheme;

    // LGPD: reading cw-theme is allowed; writing cw-theme is only allowed if preferences consent is granted
    if (window.CWConsent?.has('preferences')) {
      try {
        localStorage.setItem('cw-theme', newTheme);
      } catch {
        // Storage might be unavailable
      }
    }

    document.documentElement.dataset.theme = newTheme;
    document.documentElement.style.colorScheme = newTheme;

    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      meta.setAttribute('content', newTheme === 'dark' ? '#0a1226' : '#ffffff');
    }

    // Smooth switch transition for 400ms
    document.documentElement.classList.add('theme-anim');
    setTimeout(() => {
      document.documentElement.classList.remove('theme-anim');
    }, 400);

    // Immediate repaint of letter reveals
    repaintAllLetters(newTheme);
  };

  // Follow system theme changes live until the user explicitly chooses
  useEffect(() => {
    let hasUserChosen = false;
    try {
      hasUserChosen = localStorage.getItem('cw-theme') !== null;
    } catch {
      //
    }

    if (hasUserChosen) return;

    const mql = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      try {
        if (localStorage.getItem('cw-theme') !== null) return;
      } catch {
        //
      }
      const newTheme = e.matches ? 'dark' : 'light';
      setTheme(newTheme);
      themeRef.current = newTheme;
      document.documentElement.dataset.theme = newTheme;
      document.documentElement.style.colorScheme = newTheme;
      const meta = document.querySelector('meta[name="theme-color"]');
      if (meta) {
        meta.setAttribute('content', newTheme === 'dark' ? '#0a1226' : '#ffffff');
      }
      document.documentElement.classList.add('theme-anim');
      setTimeout(() => {
        document.documentElement.classList.remove('theme-anim');
      }, 400);
      repaintAllLetters(newTheme);
    };

    mql.addEventListener('change', handleChange);
    return () => mql.removeEventListener('change', handleChange);
  }, []);

  // Clear any pending trial modal schedule timer
  const clearTrialTimer = () => {
    if (demoTrialTimerRef.current) {
      clearTimeout(demoTrialTimerRef.current);
      demoTrialTimerRef.current = null;
    }
  };

  // Function to stop running demo
  const stopDemo = () => {
    clearTrialTimer();
    if (demoRafRef.current) {
      cancelAnimationFrame(demoRafRef.current);
      demoRafRef.current = null;
    }
    setIsDemoRunning(false);
  };

  // Listen to hashchange
  useEffect(() => {
    const handleHash = () => {
      const parsed = parseRoute(window.location.hash);
      setCurrentRoute(parsed);
      stopDemo();
      setActiveNavTab(null);
      setIsMobileMenuOpen(false);

      if (parsed.path === 'home') {
        document.title = 'CorpWise | Integração, suporte e personalização de Moodle';
        if (!parsed.section) {
          window.scrollTo(0, 0);
        }
      } else if (parsed.path === 'duvidas') {
        document.title = 'Dúvidas frequentes | CorpWise';
        if (parsed.section) {
          setOpenFaqSlug(parsed.section);
          setTimeout(() => {
            const el = document.getElementById(parsed.section!);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
          }, 60);
        } else {
          window.scrollTo(0, 0);
        }
      } else if (parsed.path === 'privacidade') {
        document.title = 'Política de Privacidade | CorpWise';
        if (parsed.section) {
          setTimeout(() => {
            const el = document.getElementById(parsed.section!);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              setActiveSectionId(parsed.section);
            }
          }, 60);
        } else {
          window.scrollTo(0, 0);
          setActiveSectionId('quem-somos');
        }
      } else if (parsed.path === 'cookies') {
        document.title = 'Política de Cookies | CorpWise';
        if (parsed.section) {
          setTimeout(() => {
            const el = document.getElementById(parsed.section!);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              setActiveSectionId(parsed.section);
            }
          }, 60);
        } else {
          window.scrollTo(0, 0);
          setActiveSectionId('o-que-sao');
        }
      } else {
        const pageData = SUBPAGES_DATA[parsed.path];
        if (pageData) {
          document.title = `${pageData.label} | CorpWise`;
        }
        if (parsed.section) {
          setTimeout(() => {
            const el = document.getElementById(parsed.section!);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              setActiveSectionId(parsed.section);
            }
          }, 60);
        } else {
          window.scrollTo(0, 0);
          setActiveSectionId(pageData?.sections[0]?.id || null);
        }
      }
    };

    window.addEventListener('hashchange', handleHash);
    handleHash();

    return () => {
      window.removeEventListener('hashchange', handleHash);
    };
  }, []);

  // Subpage H1 letter reveal effect over 1.0s
  useEffect(() => {
    if (currentRoute.path === 'home') return;
    const el = subpageH1Ref.current;
    if (!el) return;

    const chars = splitText(el);
    subH1CharsRef.current = chars;
    subH1ProgressRef.current = 0;

    const initialPal = getHeadlinePalette(themeRef.current === 'dark');
    paintChars(chars, 0, 0.35, initialPal.final, initialPal.accent, initialPal.ghost, initialPal.brand);

    const startTime = performance.now();
    let rafId: number;

    const loop = (now: number) => {
      const progress = clamp((now - startTime) / 1000, 0, 1);
      subH1ProgressRef.current = progress;
      const pal = getHeadlinePalette(themeRef.current === 'dark');
      paintChars(chars, progress, 0.35, pal.final, pal.accent, pal.ghost, pal.brand);
      if (progress < 1) {
        rafId = requestAnimationFrame(loop);
      }
    };

    rafId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafId);
  }, [currentRoute.path]);

  // Subpage cards IntersectionObserver for active sidebar item & entrance fade-in
  useEffect(() => {
    if (currentRoute.path === 'home') return;

    const cards = document.querySelectorAll('.subpage-card, .legal-section');
    if (!cards.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            setActiveSectionId(entry.target.id);
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: '-80px 0px -40% 0px',
      }
    );

    cards.forEach((c) => observer.observe(c));
    return () => observer.disconnect();
  }, [currentRoute.path]);

  // Demo cancellation on manual user interaction or timer cancellation during 700ms wait
  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      if (Math.abs(e.deltaY) > 4) {
        if (isDemoRunningRef.current) {
          stopDemo();
        } else if (demoTrialTimerRef.current) {
          clearTrialTimer();
        }
      }
    };

    const handlePointerDown = (e: PointerEvent | TouchEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest('#demo')) return;

      if (isDemoRunningRef.current) {
        if (performance.now() - demoStartTimeRef.current > 500) {
          stopDemo();
        }
      } else if (demoTrialTimerRef.current) {
        clearTrialTimer();
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const navKeys = ['ArrowUp', 'ArrowDown', 'PageUp', 'PageDown', 'Home', 'End'];
      const isSpace = e.key === ' ' || e.key === 'Spacebar';
      const target = e.target as HTMLElement | null;
      const isFormInput = target && ['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName);

      if (navKeys.includes(e.key) || (isSpace && !isFormInput)) {
        if (isDemoRunningRef.current) {
          stopDemo();
        } else if (demoTrialTimerRef.current) {
          clearTrialTimer();
        }
      }
    };

    const handleScroll = () => {
      if (isDemoRunningRef.current) {
        if (Math.abs(window.scrollY - demoExpectedScrollRef.current) > 60) {
          stopDemo();
        }
      }
    };

    window.addEventListener('wheel', handleWheel, { passive: true });
    window.addEventListener('pointerdown', handlePointerDown, { passive: true });
    window.addEventListener('touchstart', handlePointerDown, { passive: true });
    window.addEventListener('keydown', handleKeyDown, { passive: true });
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('wheel', handleWheel);
      window.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('touchstart', handlePointerDown);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  // Main canvas & scroll effects loop
  useEffect(() => {
    const isDarkInitial = (document.documentElement.dataset.theme === 'dark');
    const h1Pal = getHeadlinePalette(isDarkInitial);
    const stmtPal = getStatementPalette(isDarkInitial);

    if (h1Ref.current) {
      h1CharsRef.current = splitText(h1Ref.current);
      paintChars(h1CharsRef.current, 0, 0.35, h1Pal.final, h1Pal.accent, h1Pal.ghost, h1Pal.brand);
    }
    if (stmtRef.current) {
      stmtCharsRef.current = splitText(stmtRef.current);
      paintChars(stmtCharsRef.current, 0, 0.16, stmtPal.final, stmtPal.accent, stmtPal.ghost, stmtPal.brand);
    }
    if (h2Ref.current) {
      h2CharsRef.current = splitText(h2Ref.current);
      paintChars(h2CharsRef.current, 0, 0.35, COL_DARK_FINAL, COL_DARK_ACCENT, COL_DARK_GHOST);
    }

    const W = 96;
    const H = 60;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const context = canvas.getContext('2d');
    if (!context) return;
    const ctx: CanvasRenderingContext2D = context;

    const imgData = ctx.createImageData(W, H);
    const data = imgData.data;

    let curTip = -0.3;
    let curHalf = 0.3;
    let curSoft = 0.1;

    let inIntro = true;
    const introStartTime = performance.now();
    const introDelay = 250;
    const introDuration = 1050;

    // Theme cross-fade tracking (0 = light, 1 = dark)
    let themeMix = isDarkInitial ? 1 : 0;

    let animationFrameId: number;

    requestAnimationFrame(() => {
      document.body.classList.add('ready');
    });

    function updateScrollEffects() {
      // On sub-pages, nav is always on
      if (currentRouteRef.current.path !== 'home') {
        if (navRef.current) {
          navRef.current.classList.add('on');
          const navBtn = navRef.current.querySelector('[data-open-contact]') as HTMLElement | null;
          if (navBtn) {
            navBtn.removeAttribute('tabindex');
            navBtn.removeAttribute('aria-hidden');
          }
        }
        return;
      }

      const scrollY = window.scrollY;
      const vh = window.innerHeight;
      const q = scrollY / Math.max(1, vh);

      // Headline #h1: no scroll fade. Keep it fully opaque until it slides under the navbar
      if (h1Ref.current) {
        const h1Rect = h1Ref.current.getBoundingClientRect();
        const h1Opacity = smoothstepRange(70, 150, h1Rect.bottom);
        h1Ref.current.style.opacity = h1Opacity.toFixed(3);
      }

      // Statement rise & reveal
      const s = clamp((q - 0.69) / 0.74, 0, 1);
      const translateY = 0.205 * Math.pow(1 - s, 2) * vh;
      if (stmtRef.current) {
        stmtRef.current.style.transform = `translateY(${translateY.toFixed(1)}px)`;
      }

      const pStmt = clamp((q - 0.56) / 2.03, 0, 1);
      stmtProgressRef.current = pStmt;
      const curStmtPal = getStatementPalette(themeRef.current === 'dark');
      paintChars(stmtCharsRef.current, pStmt, 0.16, curStmtPal.final, curStmtPal.accent, curStmtPal.ghost, curStmtPal.brand);

      // Nav CTA reveal when p > 0.4
      if (navRef.current) {
        const navBtn = navRef.current.querySelector('[data-open-contact]') as HTMLElement | null;
        if (pStmt > 0.4) {
          navRef.current.classList.add('on');
          if (navBtn) {
            navBtn.removeAttribute('tabindex');
            navBtn.removeAttribute('aria-hidden');
          }
        } else {
          navRef.current.classList.remove('on');
          if (navBtn) {
            navBtn.setAttribute('tabindex', '-1');
            navBtn.setAttribute('aria-hidden', 'true');
          }
        }
      }

      // Dark split calculations
      if (splitRef.current) {
        const splitRect = splitRef.current.getBoundingClientRect();
        const splitTop = splitRect.top;

        const p2 = clamp((0.8 - splitTop / vh) / 0.65, 0, 1);
        h2ProgressRef.current = p2;
        paintChars(h2CharsRef.current, p2, 0.35, COL_DARK_FINAL, COL_DARK_ACCENT, COL_DARK_GHOST);

        if (rowRef.current) {
          if (p2 > 0.92) {
            rowRef.current.classList.add('revealed');
          } else {
            rowRef.current.classList.remove('revealed');
          }
        }

        if (shipRef.current) {
          const photoProgress = clamp(1 - splitTop / vh, 0, 1);
          const scale = 1.08 - 0.08 * photoProgress;
          shipRef.current.style.transform = `scale(${scale.toFixed(4)})`;
        }
      }
    }

    window.addEventListener('scroll', updateScrollEffects, { passive: true });
    window.addEventListener('resize', updateScrollEffects);
    updateScrollEffects();

    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(() => {
        updateScrollEffects();
      });
    }

    function getRelLum(r: number, g: number, b: number): number {
      const a = [r, g, b].map((v) => {
        v /= 255;
        return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
      });
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    }

    type AdaptiveClass = 'on-blue' | 'on-mid' | 'none';

    function classifyLuminance(L: number, cur: AdaptiveClass): AdaptiveClass {
      if (cur === 'on-blue') {
        if (L >= 0.58) return 'none';
        if (L >= 0.25) return 'on-mid';
        return 'on-blue';
      }
      if (cur === 'on-mid') {
        if (L < 0.19) return 'on-blue';
        if (L >= 0.58) return 'none';
        return 'on-mid';
      }
      // cur is 'none'
      if (L < 0.19) return 'on-blue';
      if (L < 0.52) return 'on-mid';
      return 'none';
    }

    const polyPointsX = new Float32Array(48);
    const polyPointsY = new Float32Array(48);

    function renderBowlGlow(now: number) {
      const vh = window.innerHeight;
      const vw = window.innerWidth;
      const aspect = vw / Math.max(1, vh);

      // Smoothly cross-fade canvas colours with themeMix
      const targetThemeMix = themeRef.current === 'dark' ? 1 : 0;
      themeMix += (targetThemeMix - themeMix) * 0.12;

      const curOutside = lerpRGB(COL_OUTSIDE_LIGHT, COL_OUTSIDE_DARK, themeMix);
      const curRim = lerpRGB(COL_RIM_LIGHT, COL_RIM_DARK, themeMix);
      const curCore = lerpRGB(COL_CORE_LIGHT, COL_CORE_DARK, themeMix);

      const isSubpage = currentRouteRef.current.path !== 'home';

      if (isSubpage) {
        // Subpage: drive bowl to fully flooded state (tip 2.40, half 3.00, soft 0.10)
        // so canvas viewport is solid #164E63 in light mode
        curTip += (2.40 - curTip) * 0.12;
        curHalf += (3.00 - curHalf) * 0.12;
        curSoft += (0.10 - curSoft) * 0.12;
      } else {
        const scrollY = window.scrollY;
        const q = scrollY / Math.max(1, vh);
        const target = getTargetBowl(q);

        const introElapsed = now - introStartTime;
        if (inIntro) {
          if (introElapsed < introDelay) {
            curTip = -0.3;
            curHalf = 0.3;
            curSoft = 0.1;
          } else if (introElapsed < introDelay + introDuration) {
            const progress = (introElapsed - introDelay) / introDuration;
            const easeProgress = smoothstep(progress);
            curTip = lerp(-0.3, SCROLL_KEYS[0].tip, easeProgress);
            curHalf = lerp(0.3, SCROLL_KEYS[0].half, easeProgress);
            curSoft = lerp(0.1, SCROLL_KEYS[0].soft, easeProgress);
          } else {
            inIntro = false;
          }
        } else {
          curTip += (target.tip - curTip) * 0.12;
          curHalf += (target.half - curHalf) * 0.12;
          curSoft += (target.soft - curSoft) * 0.12;
        }

        if (h1CharsRef.current.length > 0) {
          const h1Progress = clamp((now - introStartTime) / 1250, 0, 1);
          h1ProgressRef.current = h1Progress;
          const curH1Pal = getHeadlinePalette(themeRef.current === 'dark');
          paintChars(h1CharsRef.current, h1Progress, 0.35, curH1Pal.final, curH1Pal.accent, curH1Pal.ghost, curH1Pal.brand);
        }
      }

      // Idle breathing drift
      const effTip = curTip + Math.sin(now * 0.00033 + 1.3) * 0.02;
      const effHalf = curHalf + Math.sin(now * 0.0005) * 0.015;
      const effSoft = Math.max(0.01, curSoft);

      const nPoints = 48;
      const safeTip = Math.max(0.001, effTip);
      const step = (safeTip - -0.3) / (nPoints - 1);

      for (let k = 0; k < nPoints; k++) {
        const yy = -0.3 + k * step;
        const normY = yy / safeTip;
        const factor = Math.max(0, 1 - normY);
        polyPointsX[k] = effHalf * aspect * Math.pow(factor, 0.72);
        polyPointsY[k] = yy;
      }

      const halfW = W / 2;
      const RND = 0.25;

      function glowAt(u: number, v: number): number {
        const px = Math.abs(u - 0.5) * aspect;
        const py = v;

        let minDistSq = 1e9;
        for (let k = 0; k < nPoints - 1; k++) {
          const x1 = polyPointsX[k];
          const y1 = polyPointsY[k];
          const x2 = polyPointsX[k + 1];
          const y2 = polyPointsY[k + 1];

          const dx = x2 - x1;
          const dy = y2 - y1;
          const len2 = dx * dx + dy * dy;

          let tSeg = len2 > 0 ? ((px - x1) * dx + (py - y1) * dy) / len2 : 0;
          if (tSeg < 0) tSeg = 0;
          else if (tSeg > 1) tSeg = 1;

          const qx = x1 + tSeg * dx;
          const qy = y1 + tSeg * dy;
          const distSq = (px - qx) * (px - qx) + (py - qy) * (py - qy);
          if (distSq < minDistSq) {
            minDistSq = distSq;
          }
        }

        const dist = Math.sqrt(minDistSq);

        let isInside = false;
        if (py < safeTip) {
          const factor = Math.max(0, 1 - py / safeTip);
          const wallX = effHalf * aspect * Math.pow(factor, 0.72);
          if (px < wallX) {
            isInside = true;
          }
        }

        let sd = isInside ? -dist : dist;
        sd -= RND;

        return 1 - smoothstep((sd + effSoft) / (2 * effSoft));
      }

      function glowColorAt(u: number, v: number): { r: number; g: number; b: number } {
        const g = glowAt(u, v);
        if (g <= 0) {
          return { r: curOutside.r, g: curOutside.g, b: curOutside.b };
        } else if (g < 0.38) {
          const f = smoothstep(g / 0.38);
          return {
            r: lerp(curOutside.r, curRim.r, f),
            g: lerp(curOutside.g, curRim.g, f),
            b: lerp(curOutside.b, curRim.b, f),
          };
        } else {
          const f = smoothstep((g - 0.38) / 0.62);
          return {
            r: lerp(curRim.r, curCore.r, f),
            g: lerp(curRim.g, curCore.g, f),
            b: lerp(curRim.b, curCore.b, f),
          };
        }
      }

      for (let iy = 0; iy < H; iy++) {
        const py = (iy + 0.5) / H;
        const rowOffset = iy * W * 4;

        for (let ix = 0; ix < halfW; ix++) {
          const col = glowColorAt((ix + 0.5) / W, py);
          const rU8 = Math.round(col.r);
          const gU8 = Math.round(col.g);
          const bU8 = Math.round(col.b);

          const idxL = rowOffset + ix * 4;
          data[idxL] = rU8;
          data[idxL + 1] = gU8;
          data[idxL + 2] = bU8;
          data[idxL + 3] = 255;

          const mirrorX = W - 1 - ix;
          const idxR = rowOffset + mirrorX * 4;
          data[idxR] = rU8;
          data[idxR + 1] = gU8;
          data[idxR + 2] = bU8;
          data[idxR + 3] = 255;
        }
      }

      ctx.putImageData(imgData, 0, 0);

      // Hero elements adaptive styling & h1 opacity
      if (!isSubpage) {
        if (h1Ref.current) {
          const h1Rect = h1Ref.current.getBoundingClientRect();
          const h1Opacity = smoothstepRange(70, 150, h1Rect.bottom);
          h1Ref.current.style.opacity = h1Opacity.toFixed(3);
        }

        if (themeRef.current === 'dark') {
          const onBlueEls = document.querySelectorAll('.on-blue, .on-mid');
          if (onBlueEls.length > 0) {
            onBlueEls.forEach((el) => el.classList.remove('on-blue', 'on-mid'));
          }
        } else {
          // Light mode: classify each element independently using 5-point luminance sampling
          // Phase 1: Read rects & current class without mutating DOM (prevents layout thrashing)
          const elementsToSample: HTMLElement[] = [];
          const trustEl = document.querySelector<HTMLElement>('.hero .trust');
          if (trustEl) elementsToSample.push(trustEl);

          const logoCells = document.querySelectorAll<HTMLElement>('.logo-cell');
          logoCells.forEach((c) => elementsToSample.push(c));

          const trialLinkEl = document.querySelector<HTMLElement>('.hero-trial-link');
          if (trialLinkEl) elementsToSample.push(trialLinkEl);

          const ctaBtnEl = document.querySelector<HTMLElement>('.hero-cta .btn.lg');
          if (ctaBtnEl) elementsToSample.push(ctaBtnEl);

          const demoBtnEl = document.querySelector<HTMLElement>('#demo');
          if (demoBtnEl) elementsToSample.push(demoBtnEl);

          const readData = elementsToSample.map((el) => {
            const rect = el.getBoundingClientRect();
            let currentClass: AdaptiveClass = 'none';
            if (el.classList.contains('on-blue')) currentClass = 'on-blue';
            else if (el.classList.contains('on-mid')) currentClass = 'on-mid';
            return { el, rect, currentClass };
          });

          // Phase 2: Compute 5-point luminance & classification with hysteresis
          const decisions = readData.map(({ el, rect, currentClass }) => {
            if (rect.width <= 0 || rect.height <= 0 || rect.bottom < 0 || rect.top > vh) {
              return { el, nextClass: 'none' as AdaptiveClass, currentClass };
            }

            const cx = rect.left + rect.width * 0.5;
            const cy = rect.top + rect.height * 0.5;
            const w = rect.width;
            const h = rect.height;

            const samplePoints = [
              { x: cx, y: cy },
              { x: cx - 0.25 * w, y: cy },
              { x: cx + 0.25 * w, y: cy },
              { x: cx, y: cy - 0.25 * h },
              { x: cx, y: cy + 0.25 * h },
            ];

            let sumR = 0;
            let sumG = 0;
            let sumB = 0;
            for (let p = 0; p < samplePoints.length; p++) {
              const u = samplePoints[p].x / Math.max(1, vw);
              const v = samplePoints[p].y / Math.max(1, vh);
              const col = glowColorAt(u, v);
              sumR += col.r;
              sumG += col.g;
              sumB += col.b;
            }

            const avgR = sumR / 5;
            const avgG = sumG / 5;
            const avgB = sumB / 5;
            const L = getRelLum(avgR, avgG, avgB);
            const nextClass = classifyLuminance(L, currentClass);

            if (!inIntro && nextClass === 'none' && L < 0.22) {
              const elLabel = el.textContent?.trim().slice(0, 30) || el.className;
              console.warn(`[Adaptive] Element "${elLabel}" classified none with L < 0.22:`, el, { L, avgR, avgG, avgB });
            }

            return { el, nextClass, currentClass };
          });

          // Phase 3: Write DOM class changes only when changed
          decisions.forEach(({ el, nextClass, currentClass }) => {
            if (nextClass !== currentClass) {
              if (nextClass === 'none') {
                el.classList.remove('on-blue', 'on-mid');
              } else if (nextClass === 'on-blue') {
                el.classList.remove('on-mid');
                el.classList.add('on-blue');
              } else if (nextClass === 'on-mid') {
                el.classList.remove('on-blue');
                el.classList.add('on-mid');
              }
            }
          });
        }
      } else {
        // Subpage: clean up any adaptive classes
        const onBlueEls = document.querySelectorAll('.on-blue, .on-mid');
        if (onBlueEls.length > 0) {
          onBlueEls.forEach((el) => el.classList.remove('on-blue', 'on-mid'));
        }
      }
      animationFrameId = requestAnimationFrame(renderBowlGlow);
    }

    animationFrameId = requestAnimationFrame(renderBowlGlow);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('scroll', updateScrollEffects);
      window.removeEventListener('resize', updateScrollEffects);
    };
  }, []);

  // Global listeners for dropdown and mobile sheet closing
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setActiveNavTab(null);
      }
    };
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveNavTab(null);
        setIsMobileMenuOpen(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    document.addEventListener('keydown', handleGlobalKeyDown);
    return () => {
      document.removeEventListener('click', handleClickOutside);
      document.removeEventListener('keydown', handleGlobalKeyDown);
    };
  }, []);

  // Body scroll lock when mobile sheet is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else if (!dialogRef.current?.open && !trialDialogRef.current?.open && !cookiePrefsDialogRef.current?.open) {
      document.body.style.overflow = '';
    }
  }, [isMobileMenuOpen]);

  const handleTabMouseEnter = (tabId: string) => {
    if (navCloseTimerRef.current) {
      clearTimeout(navCloseTimerRef.current);
      navCloseTimerRef.current = null;
    }
    setActiveNavTab(tabId);
  };

  const handleTabMouseLeave = () => {
    if (navCloseTimerRef.current) {
      clearTimeout(navCloseTimerRef.current);
    }
    navCloseTimerRef.current = setTimeout(() => {
      setActiveNavTab(null);
    }, 180);
  };

  const handlePanelMouseEnter = () => {
    if (navCloseTimerRef.current) {
      clearTimeout(navCloseTimerRef.current);
      navCloseTimerRef.current = null;
    }
  };

  const handlePanelMouseLeave = () => {
    if (navCloseTimerRef.current) {
      clearTimeout(navCloseTimerRef.current);
    }
    navCloseTimerRef.current = setTimeout(() => {
      setActiveNavTab(null);
    }, 180);
  };

  const handleTabClick = (tabId: string) => {
    if (navCloseTimerRef.current) {
      clearTimeout(navCloseTimerRef.current);
      navCloseTimerRef.current = null;
    }
    setActiveNavTab((prev) => (prev === tabId ? null : tabId));
  };

  const handleTabKeyDown = (e: React.KeyboardEvent, tabId: string) => {
    if (e.key === 'Escape') {
      setActiveNavTab(null);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleTabClick(tabId);
    }
  };

  // Trial / Access Request Modal Opener
  const handleOpenTrial = (opener: HTMLElement) => {
    trialOpenerRef.current = opener;
    const dialog = trialDialogRef.current;
    if (!dialog) return;
    setTrialSubmitSuccess(false);
    setTrialPopupBlockedUrl(null);
    setTrialFormState({
      nome: '',
      email: '',
      empresa: '',
      porte: '',
    });
    setSelectedChips([]);
    setTrialTouchedFields({});
    document.body.style.overflow = 'hidden';
    if (!dialog.open) {
      dialog.showModal();
    }
    requestAnimationFrame(() => {
      dialog.classList.add('in');
    });
  };

  // Schedule opening trial modal after demo natural finish
  const scheduleTrialModal = () => {
    clearTrialTimer();
    if (!DEMO_OPEN_TRIAL) return;
    demoTrialTimerRef.current = setTimeout(() => {
      demoTrialTimerRef.current = null;
      const demoBtn = document.getElementById('demo');
      handleOpenTrial(demoBtn || document.body);
    }, DEMO_OPEN_DELAY);
  };

  // Demo auto-scroll toggle handler
  const handleToggleDemo = () => {
    clearTrialTimer();
    if (isDemoRunning) {
      stopDemo();
      return;
    }

    // Starting demo closes any open dropdown panel or mobile sheet
    setActiveNavTab(null);
    setIsMobileMenuOpen(false);

    const initialTarget = getFaqTarget();

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      window.scrollTo(0, initialTarget);
      setDemoStatus('finished');
      scheduleTrialModal();
      return;
    }

    const currentScroll = window.scrollY;

    setIsDemoRunning(true);
    setDemoStatus('running');
    demoStartTimeRef.current = performance.now();
    demoExpectedScrollRef.current = currentScroll;

    // If already at or below the FAQ target (scrollY >= target - 4), scroll back to top over 1.2s (DEMO_REWIND_DURATION)
    if (currentScroll >= initialTarget - 4) {
      const topDuration = DEMO_REWIND_DURATION;
      const topStartTime = performance.now();

      const scrollToTopLoop = (now: number) => {
        const elapsed = now - topStartTime;
        const t = clamp(elapsed / topDuration, 0, 1);
        const eased = easeInOutSine(t);
        const y = currentScroll * (1 - eased);
        demoExpectedScrollRef.current = y;
        window.scrollTo(0, y);

        if (t < 1) {
          demoRafRef.current = requestAnimationFrame(scrollToTopLoop);
        } else {
          window.scrollTo(0, 0);
          startDownwardScroll(0);
        }
      };
      demoRafRef.current = requestAnimationFrame(scrollToTopLoop);
    } else {
      startDownwardScroll(currentScroll);
    }
  };

  const startDownwardScroll = (startY: number) => {
    demoStartTimeRef.current = performance.now();
    const initialTarget = getFaqTarget();
    const distance = Math.max(10, Math.abs(initialTarget - startY));
    const duration = clamp((distance / DEMO_SPEED) * 1000, DEMO_MIN_DURATION, DEMO_MAX_DURATION);
    const startTime = performance.now();

    const loop = (now: number) => {
      const elapsed = now - startTime;
      const t = clamp(elapsed / duration, 0, 1);
      const eased = easeInOutSine(t);
      const liveTarget = getFaqTarget();
      const currentY = startY + (liveTarget - startY) * eased;
      demoExpectedScrollRef.current = currentY;
      window.scrollTo(0, currentY);

      if (t < 1) {
        demoRafRef.current = requestAnimationFrame(loop);
      } else {
        demoRafRef.current = null;
        setIsDemoRunning(false);
        setDemoStatus('finished');
        scheduleTrialModal();
      }
    };
    demoRafRef.current = requestAnimationFrame(loop);
  };

  // Contact Modal handlers
  const handleOpenContact = (opener: HTMLElement, initialMensagem?: string) => {
    openerRef.current = opener;
    const dialog = dialogRef.current;
    if (!dialog) return;
    setSubmitSuccess(false);
    setPopupBlockedUrl(null);
    setFormState({
      nome: '',
      email: '',
      empresa: '',
      mensagem: initialMensagem ?? '',
    });
    setTouchedFields({});
    document.body.style.overflow = 'hidden';
    if (!dialog.open) {
      dialog.showModal();
    }
    requestAnimationFrame(() => {
      dialog.classList.add('in');
    });
  };

  const handleOpenContactWithTopic = (topic: string, opener?: HTMLElement) => {
    setActiveNavTab(null);
    setIsMobileMenuOpen(false);
    const messageTemplate = `Olá! Gostaria de falar sobre ${topic} para a minha empresa.`;
    handleOpenContact(opener || document.body, messageTemplate);
  };

  const handleCloseContact = () => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    dialog.classList.remove('in');
    setTimeout(() => {
      if (dialog.open) {
        dialog.close();
      }
      if (!isMobileMenuOpen && !trialDialogRef.current?.open && !cookiePrefsDialogRef.current?.open) {
        document.body.style.overflow = '';
      }
      if (openerRef.current) {
        openerRef.current.focus();
      }
    }, 250);
  };

  const handleDialogNativeClose = () => {
    if (!isMobileMenuOpen && !trialDialogRef.current?.open && !cookiePrefsDialogRef.current?.open) {
      document.body.style.overflow = '';
    }
    if (openerRef.current) {
      openerRef.current.focus();
    }
  };

  const getEmailPayload = () => {
    const nome = formState.nome.trim();
    const email = formState.email.trim();
    const empresa = formState.empresa.trim();
    const mensagem = formState.mensagem.trim();

    const recipients = CONTACT_EMAIL;
    const subject = 'Contato pelo site CorpWise';

    let body = `Olá! Gostaria de falar com a CorpWise sobre o Moodle da minha empresa.\n\nNome: ${nome}\nE-mail: ${email}`;
    if (empresa) {
      body += `\nEmpresa: ${empresa}`;
    }
    body += `\n\nMensagem:\n${mensagem}`;

    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${recipients}&su=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;

    const mailtoUrl = `mailto:${recipients}?subject=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;

    return { gmailUrl, mailtoUrl };
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) {
      return;
    }

    const { gmailUrl } = getEmailPayload();
    const win = window.open(gmailUrl, '_blank', 'noopener');
    if (!win) {
      setPopupBlockedUrl(gmailUrl);
    } else {
      setPopupBlockedUrl(null);
    }
    setSubmitSuccess(true);
  };

  const handleOpenGmailAgain = () => {
    const { gmailUrl } = getEmailPayload();
    const win = window.open(gmailUrl, '_blank', 'noopener');
    if (!win) {
      setPopupBlockedUrl(gmailUrl);
    } else {
      setPopupBlockedUrl(null);
    }
  };

  const handleOpenEmailApp = (e: React.MouseEvent) => {
    e.preventDefault();
    const { mailtoUrl } = getEmailPayload();
    window.location.href = mailtoUrl;
  };


  const handleCloseTrial = () => {
    const dialog = trialDialogRef.current;
    if (!dialog) return;
    dialog.classList.remove('in');
    setTimeout(() => {
      if (dialog.open) {
        dialog.close();
      }
      if (!isMobileMenuOpen && !dialogRef.current?.open) {
        document.body.style.overflow = '';
      }
      if (trialOpenerRef.current) {
        trialOpenerRef.current.focus();
      }
    }, 250);
  };

  const handleTrialDialogNativeClose = () => {
    if (!isMobileMenuOpen && !dialogRef.current?.open && !cookiePrefsDialogRef.current?.open) {
      document.body.style.overflow = '';
    }
    if (trialOpenerRef.current) {
      trialOpenerRef.current.focus();
    }
  };

  const openPreferencesModal = (opener?: HTMLElement | null) => {
    stopDemo();
    cookiePrefsOpenerRef.current = opener || null;
    const current = readStoredConsent();
    setPrefsAllowed(current ? !!current.categories.preferences : false);
    setPrefsFeedback('');
    const dialog = cookiePrefsDialogRef.current;
    if (!dialog) return;
    if (!dialog.open) {
      dialog.showModal();
      requestAnimationFrame(() => dialog.classList.add('in'));
      document.body.style.overflow = 'hidden';
    }
  };

  const closePreferencesModal = (immediate = false) => {
    const dialog = cookiePrefsDialogRef.current;
    if (!dialog) return;
    if (immediate) {
      dialog.classList.remove('in');
      dialog.close();
      if (!isMobileMenuOpen && !dialogRef.current?.open && !trialDialogRef.current?.open) {
        document.body.style.overflow = '';
      }
      if (cookiePrefsOpenerRef.current) {
        cookiePrefsOpenerRef.current.focus();
      }
      return;
    }
    dialog.classList.remove('in');
    setTimeout(() => {
      if (dialog.open) {
        dialog.close();
      }
      if (!isMobileMenuOpen && !dialogRef.current?.open && !trialDialogRef.current?.open) {
        document.body.style.overflow = '';
      }
      if (cookiePrefsOpenerRef.current) {
        cookiePrefsOpenerRef.current.focus();
      }
    }, 250);
  };

  useEffect(() => {
    registerPreferencesOpener(() => {
      openPreferencesModal();
    });
  }, []);

  // Show banner after 1.2s if no consent recorded yet
  useEffect(() => {
    if (storedConsent === null) {
      const timer = setTimeout(() => {
        if (!dialogRef.current?.open && !trialDialogRef.current?.open && !cookiePrefsDialogRef.current?.open) {
          setShowCookieBanner(true);
        }
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [storedConsent]);

  const handleRejectNonNecessary = () => {
    writeConsent({ necessary: true, preferences: false, analytics: false, marketing: false });
    setStoredConsent(readStoredConsent());
    setShowCookieBanner(false);
  };

  const handleOpenCustomize = (e: React.MouseEvent<HTMLButtonElement>) => {
    setShowCookieBanner(false);
    openPreferencesModal(e.currentTarget);
  };

  const handleAcceptAll = () => {
    writeConsent({ necessary: true, preferences: true, analytics: USES_ANALYTICS, marketing: USES_MARKETING });
    setStoredConsent(readStoredConsent());
    setShowCookieBanner(false);
  };

  const handlePrefsRejectNonNecessary = () => {
    writeConsent({ necessary: true, preferences: false, analytics: false, marketing: false });
    setStoredConsent(readStoredConsent());
    setPrefsAllowed(false);
    setPrefsFeedback('Preferências salvas.');
    setTimeout(() => {
      closePreferencesModal();
    }, 900);
  };

  const handlePrefsSaveChoices = () => {
    writeConsent({ necessary: true, preferences: prefsAllowed, analytics: false, marketing: false });
    setStoredConsent(readStoredConsent());
    setPrefsFeedback('Preferências salvas.');
    setTimeout(() => {
      closePreferencesModal();
    }, 900);
  };

  const handlePrefsAcceptAll = () => {
    writeConsent({ necessary: true, preferences: true, analytics: USES_ANALYTICS, marketing: USES_MARKETING });
    setStoredConsent(readStoredConsent());
    setPrefsAllowed(true);
    setPrefsFeedback('Preferências salvas.');
    setTimeout(() => {
      closePreferencesModal();
    }, 900);
  };

  const handleToggleChip = (chip: string) => {
    setSelectedChips((prev) =>
      prev.includes(chip) ? prev.filter((c) => c !== chip) : [...prev, chip]
    );
  };

  const getTrialEmailPayload = () => {
    const nome = trialFormState.nome.trim() || '-';
    const email = trialFormState.email.trim() || '-';
    const empresa = trialFormState.empresa.trim() || '-';
    const porte = trialFormState.porte.trim() || '-';
    const chipsText = selectedChips.length > 0 ? selectedChips.join(', ') : '-';

    const recipients = CONTACT_EMAIL;
    const subject = 'Pedido de acesso ao ambiente de teste Moodle - CorpWise';

    const body = `Olá! Gostaria de pedir acesso ao ambiente de teste Moodle da CorpWise.\n\nNome: ${nome}\nE-mail: ${email}\nEmpresa: ${empresa}\nPorte da empresa: ${porte}\nInteresses: ${chipsText}`;

    const gmailUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${recipients}&su=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;

    const mailtoUrl = `mailto:${recipients}?subject=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;

    return { gmailUrl, mailtoUrl };
  };

  const handleTrialSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!form.reportValidity()) {
      return;
    }

    const { gmailUrl } = getTrialEmailPayload();
    const win = window.open(gmailUrl, '_blank', 'noopener');
    if (!win) {
      setTrialPopupBlockedUrl(gmailUrl);
    } else {
      setTrialPopupBlockedUrl(null);
    }
    setTrialSubmitSuccess(true);
  };

  const handleTrialOpenGmailAgain = () => {
    const { gmailUrl } = getTrialEmailPayload();
    const win = window.open(gmailUrl, '_blank', 'noopener');
    if (!win) {
      setTrialPopupBlockedUrl(gmailUrl);
    } else {
      setTrialPopupBlockedUrl(null);
    }
  };

  const handleTrialOpenEmailApp = (e: React.MouseEvent) => {
    e.preventDefault();
    const { mailtoUrl } = getTrialEmailPayload();
    window.location.href = mailtoUrl;
  };

  // FAQ Accordion handlers
  const handleToggleFaq = (slug: string) => {
    setOpenFaqSlug((prev) => (prev === slug ? null : slug));
  };

  const handleFaqKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>, index: number, prefix: string) => {
    const total = FAQ_DATA.length;
    let targetIndex: number | null = null;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      targetIndex = (index + 1) % total;
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      targetIndex = (index - 1 + total) % total;
    } else if (e.key === 'Home') {
      e.preventDefault();
      targetIndex = 0;
    } else if (e.key === 'End') {
      e.preventDefault();
      targetIndex = total - 1;
    }
    if (targetIndex !== null) {
      const targetSlug = FAQ_DATA[targetIndex].slug;
      const targetBtn = document.getElementById(`${prefix}-faq-btn-${targetSlug}`);
      if (targetBtn) {
        targetBtn.focus();
      }
    }
  };

  const renderFaqAccordion = (prefix: string) => (
    <div className="faq-accordion" role="presentation">
      {FAQ_DATA.map((item, idx) => {
        const isOpen = openFaqSlug === item.slug;
        const btnId = `${prefix}-faq-btn-${item.slug}`;
        const ansId = `${prefix}-faq-ans-${item.slug}`;
        return (
          <div key={item.slug} className={`faq-item ${isOpen ? 'open' : ''}`} id={item.slug}>
            <button
              type="button"
              id={btnId}
              className={`faq-q ${isOpen ? 'open' : ''}`}
              aria-expanded={isOpen}
              aria-controls={ansId}
              onClick={() => handleToggleFaq(item.slug)}
              onKeyDown={(e) => handleFaqKeyDown(e, idx, prefix)}
            >
              <span className="faq-q-text">{item.q}</span>
              <span className="faq-icon" aria-hidden="true">
                <span className="faq-icon-line faq-icon-h" />
                <span className="faq-icon-line faq-icon-v" />
              </span>
            </button>
            <div
              id={ansId}
              role="region"
              aria-labelledby={btnId}
              className={`faq-a ${isOpen ? 'open' : ''}`}
            >
              <div className="faq-a-inner">
                <p>{item.a}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  const renderFooter = () => (
    <footer className="subpage-footer">
      <div className="subpage-footer-inner">
        <div className="subpage-footer-brand">
          <a href="#/" className="nav-brand" style={{ color: '#fff' }} aria-label="CorpWise, página inicial">
            <img className="logo footer-logo" src="logo-corpwise-branca.png" alt="CorpWise" width="120" height="26" />
          </a>
          <p className="subpage-footer-desc">
            Integração, implantação, personalização e suporte de Moodle para empresas.
          </p>
        </div>

        <div className="subpage-footer-links">
          <div className="subpage-footer-col">
            <div className="subpage-footer-heading">Navegação</div>
            <a href="#/servicos" className="subpage-footer-link">Serviços</a>
            <a href="#/solucoes" className="subpage-footer-link">Soluções</a>
            <a href="#/plugins" className="subpage-footer-link">Plugins</a>
            <a href="#/como-funciona" className="subpage-footer-link">Como funciona</a>
            <a href="#/duvidas" className="subpage-footer-link">Dúvidas</a>
          </div>
          <div className="subpage-footer-col">
            <div className="subpage-footer-heading">Mais</div>
            <a href="#/suporte" className="subpage-footer-link">Suporte</a>
            <a href="#/planos" className="subpage-footer-link">Planos</a>
            <a href="#/empresa" className="subpage-footer-link">Empresa</a>
            <a
              href="https://corpwisegestao.com.br/login/index.php"
              target="_blank"
              rel="noopener noreferrer"
              className="subpage-footer-link"
            >
              Entrar na plataforma
            </a>
          </div>
          <div className="subpage-footer-col subpage-footer-col-contact">
            <div className="subpage-footer-heading">Contato</div>
            <a
              href="https://www.instagram.com/corpwisegestao/"
              target="_blank"
              rel="noopener noreferrer"
              className="subpage-footer-link subpage-footer-link-icon"
              aria-label="Instagram da CorpWise (abre em nova aba)"
            >
              <svg
                className="footer-icon"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
              </svg>
              <span>Instagram</span>
            </a>
            <a
              href="mailto:atendimento@corpwisegestao.com.br"
              className="subpage-footer-link subpage-footer-link-icon subpage-footer-email"
            >
              <svg
                className="footer-icon"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
              </svg>
              <span>atendimento@corpwisegestao.com.br</span>
            </a>
          </div>
          <div className="subpage-footer-col">
            <div className="subpage-footer-heading">Legal</div>
            <a href="#/privacidade" className="subpage-footer-link">Política de Privacidade</a>
            <a href="#/cookies" className="subpage-footer-link">Política de Cookies</a>
            <button
              type="button"
              className="subpage-footer-link subpage-footer-btn-link"
              onClick={() => openPreferencesModal()}
            >
              Preferências de cookies
            </button>
          </div>
        </div>
      </div>

      <div className="subpage-footer-bottom">
        <p>© 2026 CorpWise Gestão. Todos os direitos reservados. Não somos uma empresa de IA.</p>
        {LEGAL.cnpj && LEGAL.cnpj.trim() !== '' ? (
          <p className="subpage-footer-legal-line">
            {LEGAL.razaoSocial && LEGAL.razaoSocial.trim() !== ''
              ? `${LEGAL.razaoSocial} · CNPJ ${LEGAL.cnpj}`
              : `CorpWise · CNPJ ${LEGAL.cnpj}`}
          </p>
        ) : null}
      </div>
    </footer>
  );

  const currentTabObj = NAV_TABS.find((t) => t.id === activeNavTab);
  const currentSubpage = SUBPAGES_DATA[currentRoute.path];

  const demoButtonLabel = isDemoRunning
    ? 'Parar demonstração'
    : demoStatus === 'finished'
    ? 'Rever demonstração'
    : 'Ver demonstração';

  return (
    <>
      {/* Atmosphere background with 96x60 stretched canvas */}
      <div className="atmo">
        <canvas id="bg" ref={canvasRef} width={96} height={60} />
      </div>

      {/* Floating Navbar */}
      <header className="nav" id="nav" ref={navRef}>
        <a
          href="#/"
          className="nav-brand"
          aria-label="CorpWise, página inicial"
          onClick={() => {
            setActiveNavTab(null);
            setIsMobileMenuOpen(false);
          }}
        >
          <img className="logo logo-light" src="logo-corpwise.png" alt="CorpWise" width="111" height="24" />
          <img className="logo logo-dark" src="logo-corpwise-branca.png" alt="" aria-hidden="true" width="111" height="24" />
        </a>

        {/* Center: 7 Dropdown Tabs + Dúvidas Plain Link */}
        <div className="nav-center">
          <nav className="nav-links" aria-label="Navegação principal">
            {NAV_TABS.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`nav-item-btn ${activeNavTab === tab.id ? 'active' : ''}`}
                aria-expanded={activeNavTab === tab.id}
                aria-haspopup="true"
                aria-controls={`panel-${tab.id}`}
                onClick={() => handleTabClick(tab.id)}
                onMouseEnter={() => handleTabMouseEnter(tab.id)}
                onMouseLeave={handleTabMouseLeave}
                onKeyDown={(e) => handleTabKeyDown(e, tab.id)}
              >
                <span>{tab.label}</span>
                <svg
                  className="nav-chevron"
                  width="12"
                  height="12"
                  viewBox="0 0 12 12"
                  fill="none"
                >
                  <path
                    d="M3 4.5 6 7.5 9 4.5"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            ))}
            <a
              href="#/duvidas"
              className="nav-item-btn nav-link-item"
              onClick={() => setActiveNavTab(null)}
            >
              <span>Dúvidas</span>
            </a>
          </nav>
        </div>

        {/* Right Group: Hamburger (<=1240px), Entrar, Theme Toggle, CTA */}
        <div className="nav-right">
          <button
            type="button"
            className="nav-hamburger"
            onClick={() => setIsMobileMenuOpen((prev) => !prev)}
            aria-label={isMobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            ) : (
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="4" y1="7" x2="20" y2="7" />
                <line x1="4" y1="12" x2="20" y2="12" />
                <line x1="4" y1="17" x2="20" y2="17" />
              </svg>
            )}
          </button>

          <a
            href="https://corpwisegestao.com.br/login/index.php"
            target="_blank"
            rel="noopener noreferrer"
            className="nav-login"
          >
            Entrar
          </a>

          {/* Theme Toggle Button (Desktop & 821-1240px) */}
          <button
            type="button"
            id="theme"
            className="theme-btn"
            aria-pressed={theme === 'dark'}
            aria-label={theme === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro'}
            title={theme === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro'}
            onClick={toggleTheme}
          >
            {/* Moon icon shown in light mode */}
            <svg
              className="theme-icon theme-icon-moon"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>
            {/* Sun icon shown in dark mode */}
            <svg
              className="theme-icon theme-icon-sun"
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="5" />
              <line x1="12" y1="1" x2="12" y2="3" />
              <line x1="12" y1="21" x2="12" y2="23" />
              <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
              <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
              <line x1="1" y1="12" x2="3" y2="12" />
              <line x1="21" y1="12" x2="23" y2="12" />
              <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
              <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
            </svg>
          </button>

          <div className="navcta">
            <button
              type="button"
              className="btn"
              data-open-contact
              onClick={(e) => handleOpenContact(e.currentTarget)}
              tabIndex={-1}
              aria-hidden="true"
              style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
            >
              <span className="full">Falar com a CorpWise</span>
              <span className="short">Falar conosco</span>
              <span className="dot">
                <svg className="chev" width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path
                    d="M4.5 2.5 8 6l-3.5 3.5"
                    stroke="#0b1d3a"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
            </button>
          </div>
        </div>

        {/* Desktop Mega Menu Panel Card */}
        {currentTabObj && (
          <div
            className="mega-panel-wrapper"
            onMouseEnter={handlePanelMouseEnter}
            onMouseLeave={handlePanelMouseLeave}
          >
            <div
              className="mega-panel-card"
              id={`panel-${currentTabObj.id}`}
              role="region"
              aria-label={`Menu ${currentTabObj.label}`}
            >
              <div className={`mega-rows ${currentTabObj.id === 'como-funciona' ? 'mega-rows-timeline' : ''}`}>
                {currentTabObj.rows.map((row, idx) => (
                  <a
                    key={idx}
                    href={row.href}
                    className="mega-row"
                    data-topic={row.topic}
                    onClick={() => {
                      setActiveNavTab(null);
                    }}
                  >
                    <div className="mega-row-icon">
                      {currentTabObj.id === 'como-funciona' ? (
                        <span className="step-num">{idx + 1}</span>
                      ) : (
                        row.icon
                      )}
                    </div>
                    <div className="mega-row-body">
                      <div className="mega-row-title">
                        {row.title}
                        {row.tag && <span className="mega-tag">{row.tag}</span>}
                      </div>
                      <div className="mega-row-desc">{row.desc}</div>
                    </div>
                  </a>
                ))}

                <a
                  href={`#/${currentTabObj.id}`}
                  className="mega-see-all"
                  onClick={() => {
                    setActiveNavTab(null);
                  }}
                >
                  Ver tudo em {currentTabObj.label} →
                </a>
              </div>

              <div className="mega-featured">
                <div>
                  <div className="mega-featured-title">{currentTabObj.featured.title}</div>
                  <div className="mega-featured-text">{currentTabObj.featured.text}</div>
                </div>
                <button
                  type="button"
                  className="mega-featured-btn"
                  data-topic={currentTabObj.featured.topic}
                  onClick={(e) => handleOpenContactWithTopic(currentTabObj.featured.topic, e.currentTarget)}
                >
                  {currentTabObj.featured.button}
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Mobile Sheet Overlay and Accordion */}
      {isMobileMenuOpen && (
        <div className="mobile-sheet-overlay" onClick={() => setIsMobileMenuOpen(false)}>
          <div
            className="mobile-sheet"
            onClick={(e) => e.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-label="Menu de navegação"
          >
            <div className="mobile-sheet-header">
              <span className="mobile-sheet-title">Menu</span>
              <button
                type="button"
                className="mobile-sheet-close"
                onClick={() => setIsMobileMenuOpen(false)}
                aria-label="Fechar menu"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              </button>
            </div>

            <div className="mobile-sheet-accordion">
              {NAV_TABS.map((tab) => {
                const isOpen = mobileAccordionOpen === tab.id;
                return (
                  <div key={tab.id} className="mobile-acc-item">
                    <button
                      type="button"
                      className={`mobile-acc-trigger ${isOpen ? 'open' : ''}`}
                      onClick={() => setMobileAccordionOpen(isOpen ? null : tab.id)}
                      aria-expanded={isOpen}
                    >
                      <span>{tab.label}</span>
                      <svg
                        className="mobile-acc-chev"
                        width="12"
                        height="12"
                        viewBox="0 0 12 12"
                        fill="none"
                      >
                        <path
                          d="M3 4.5 6 7.5 9 4.5"
                          stroke="currentColor"
                          strokeWidth="1.6"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </button>
                    {isOpen && (
                      <div className="mobile-acc-content">
                        {tab.rows.map((row, idx) => (
                          <a
                            key={idx}
                            href={row.href}
                            className="mega-row"
                            data-topic={row.topic}
                            onClick={() => {
                              setIsMobileMenuOpen(false);
                            }}
                          >
                            <div className="mega-row-icon">
                              {tab.id === 'como-funciona' ? (
                                <span className="step-num">{idx + 1}</span>
                              ) : (
                                row.icon
                              )}
                            </div>
                            <div className="mega-row-body">
                              <div className="mega-row-title">
                                {row.title}
                                {row.tag && <span className="mega-tag">{row.tag}</span>}
                              </div>
                              <div className="mega-row-desc">{row.desc}</div>
                            </div>
                          </a>
                        ))}

                        <a
                          href={`#/${tab.id}`}
                          className="mega-see-all"
                          onClick={() => {
                            setIsMobileMenuOpen(false);
                          }}
                        >
                          Ver tudo em {tab.label} →
                        </a>
                      </div>
                    )}
                  </div>
                );
              })}

              <a
                href="#/duvidas"
                className="mobile-duvidas-row"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <span>Dúvidas frequentes</span>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path
                    d="M4.5 2.5 8 6l-3.5 3.5"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </a>
            </div>

            <div className="mobile-sheet-footer">
              <button
                type="button"
                className="mobile-sheet-cta-btn"
                onClick={(e) => {
                  setIsMobileMenuOpen(false);
                  handleOpenContact(e.currentTarget);
                }}
              >
                <span>Falar com a CorpWise</span>
                <span className="mobile-sheet-cta-dot" />
              </button>

              {/* Mobile theme toggle row */}
              <div className="mobile-theme-row">
                <span>Modo escuro</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={theme === 'dark'}
                  className="mobile-theme-switch"
                  onClick={toggleTheme}
                  aria-label={theme === 'dark' ? 'Ativar modo claro' : 'Ativar modo escuro'}
                >
                  <span className="mobile-theme-track">
                    <span className="mobile-theme-knob" />
                  </span>
                </button>
              </div>

              <a
                href="https://corpwisegestao.com.br/login/index.php"
                target="_blank"
                rel="noopener noreferrer"
                className="mobile-sheet-login-btn"
              >
                Entrar na plataforma
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Main Home View */}
      <main
        id="home-main"
        hidden={currentRoute.path !== 'home'}
        style={{ display: currentRoute.path === 'home' ? 'block' : 'none' }}
      >
        {/* Scene 1: Hero */}
        <section className="hero" id="hero">
          <h1 className="hero-h1" id="h1" ref={h1Ref}>
            <span className="hl">Moodle</span> integrado, configurado<br />
            e personalizado para a sua empresa
          </h1>

          <p className="trust fade-up" style={{ ['--d' as string]: '1.15s' }}>
            Especialistas em Moodle e nos plugins que usamos no dia a dia
          </p>

          <div className="hero-cta fade-up" style={{ ['--d' as string]: '1.30s' }}>
            <button
              type="button"
              className="hero-trial-link"
              onClick={(e) => handleOpenTrial(e.currentTarget)}
            >
              Quer testar antes? Peça um acesso de degustação →
            </button>

            <button
              type="button"
              className="btn lg"
              data-open-contact
              onClick={(e) => handleOpenContact(e.currentTarget)}
              style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
            >
              <span className="lbl">Falar com a CorpWise</span>
              <span className="dot">
                <svg className="chev" width="16" height="16" viewBox="0 0 12 12" fill="none">
                  <path
                    d="M4.5 2.5 8 6l-3.5 3.5"
                    stroke="#0b1d3a"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
            </button>

            <button
              type="button"
              className={`btn-demo ${isDemoRunning ? 'running' : ''}`}
              id="demo"
              aria-pressed={isDemoRunning}
              onClick={handleToggleDemo}
            >
              <span className="btn-demo-circle">
                {isDemoRunning ? (
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <rect x="2.5" y="2" width="3" height="10" rx="1" fill="currentColor" />
                    <rect x="8.5" y="2" width="3" height="10" rx="1" fill="currentColor" />
                  </svg>
                ) : (
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <path d="M4 2.5L11.5 7L4 11.5V2.5Z" fill="currentColor" />
                  </svg>
                )}
              </span>
              <span className="btn-demo-label">{demoButtonLabel}</span>
            </button>
          </div>

          {/* 7-cell logo grid: Plugins We Use (4 in row 1, 3 in row 2) */}
          <div className="logos">
            {/* Cell 1: Attendance */}
            <div className="logo-cell row-1 fade-up" style={{ ['--d' as string]: '1.25s' }}>
              <span className="logo-attendance wordmark-text">Attendance</span>
            </div>

            {/* Cell 2: LEVEL UP! */}
            <div className="logo-cell row-1 fade-up" style={{ ['--d' as string]: '1.32s' }}>
              <svg width="24" height="20" viewBox="0 0 24 20" fill="none">
                <rect x="3" y="10" width="3.5" height="10" rx="1.5" fill="currentColor" />
                <rect x="9.5" y="5" width="3.5" height="15" rx="1.5" fill="currentColor" />
                <rect x="16" y="8" width="3.5" height="12" rx="1.5" fill="currentColor" />
              </svg>
              <span className="wordmark-text">LEVEL UP!</span>
            </div>

            {/* Cell 3: MOOVE */}
            <div
              className="logo-cell row-1 fade-up"
              style={{ ['--d' as string]: '1.39s' }}
              title="Moove"
              aria-label="Moove"
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
                <polyline
                  points="5,5 10,10 5,15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <polyline
                  points="11,5 16,10 11,15"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
              <span className="logo-moove wordmark-text">MOOVE</span>
            </div>

            {/* Cell 4: H5P */}
            <div className="logo-cell row-1 fade-up" style={{ ['--d' as string]: '1.46s' }}>
              <span className="logo-h5p wordmark-text">H5P</span>
            </div>

            {/* Cell 5: CUSTOM CERTIFICATE (row 2) */}
            <div className="logo-cell row-2 fade-up" style={{ ['--d' as string]: '1.50s' }}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <circle cx="10" cy="10" r="7.5" stroke="currentColor" strokeWidth="2" fill="none" />
                <circle cx="10" cy="10" r="2.5" fill="currentColor" />
              </svg>
              <span className="wordmark-text">CUSTOM CERTIFICATE</span>
            </div>

            {/* Cell 6: CONFIGURABLE REPORTS (row 2) */}
            <div className="logo-cell row-2 fade-up" style={{ ['--d' as string]: '1.57s' }}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <polyline
                  points="3,15 7,9 12,13 17,5"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  fill="none"
                />
              </svg>
              <span className="wordmark-text">CONFIGURABLE REPORTS</span>
            </div>

            {/* Cell 7: COMPLETION PROGRESS (row 2) */}
            <div className="logo-cell row-2 fade-up" style={{ ['--d' as string]: '1.64s' }}>
              <svg width="24" height="20" viewBox="0 0 24 20" fill="none">
                <rect x="2" y="7" width="20" height="7" rx="3.5" stroke="currentColor" strokeWidth="1.8" fill="none" />
                <rect x="3.5" y="8.5" width="11" height="4" rx="2" fill="currentColor" />
              </svg>
              <span className="wordmark-text">COMPLETION PROGRESS</span>
            </div>
          </div>
        </section>

        {/* Scene 2: Statement (pinned) */}
        <section className="statement" id="statement">
          <div className="pin">
            <p id="stmt" ref={stmtRef}>
              A CorpWise é uma empresa voltada a você e seu Moodle,<br />{' '}
              integramos, configuramos e personalizamos a plataforma<br />{' '}
              com a sua marca, os seus plugins e os seus sistemas,<br />{' '}
              e damos suporte para o seu treinamento nunca parar.
            </p>
          </div>
        </section>

        {/* Scene 3: Dark Split */}
        <section className="split" id="split" ref={splitRef}>
          <div className="l">
            <h2 id="h2" ref={h2Ref}>
              Seu time aprende.<br />A gente cuida do Moodle.
            </h2>

            <div id="row" ref={rowRef}>
              <div className="hook-item">
                <h3>Seu Moodle com a cara da sua empresa.</h3>
                <p>
                  Tema, identidade visual, certificados e fluxos de matrícula personalizados. Chega de plataforma com cara de genérica.
                </p>
              </div>

              <div className="hook-item">
                <h3>Plugin certo, sem dor de cabeça.</h3>
                <p>
                  Escolhemos, instalamos e configuramos os plugins que a sua operação precisa e mantemos tudo compatível a cada atualização.
                </p>
              </div>

              <div className="hook-item">
                <h3>Moodle conectado ao resto da empresa.</h3>
                <p>
                  Integramos com RH, ERP, login único (SSO) e ferramentas de videoconferência, para os dados fluírem sem planilha no meio.
                </p>
              </div>

              <div className="hook-item">
                <h3>Suporte quando o treinamento não pode parar.</h3>
                <p>
                  Atendimento técnico para a sua equipe e para os alunos. Quer mais agilidade? Temos uma ferramenta de suporte integrada ao Moodle.
                </p>
                <span className="hook-tag">Opcional · custo adicional</span>
              </div>
            </div>
          </div>

          <div className="r">
            <img
              id="ship"
              ref={shipRef}
              src="https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1400&q=85"
              alt="Equipe colaborando em um espaço de trabalho moderno com um painel de aprendizagem na tela"
              loading="eager"
            />
          </div>
        </section>

        {/* Scene 4: Frequently Asked Questions */}
        <section className="faq" id="faq">
          <div className="faq-grid">
            <div className="faq-left">
              <div className="faq-eyebrow">DÚVIDAS FREQUENTES</div>
              <h2 className="faq-title">Perguntas frequentes sobre o Moodle e nossos serviços</h2>
              <p className="faq-intro">
                Entenda como funcionam os planos, a diferença entre instalar e hospedar, o que está incluído no suporte e como podemos ajudar sua empresa.
              </p>
              <button
                type="button"
                className="btn"
                data-open-contact
                onClick={(e) => handleOpenContact(e.currentTarget)}
                style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
              >
                <span className="lbl">Falar com a CorpWise</span>
                <span className="dot">
                  <svg className="chev" width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <path
                      d="M4.5 2.5 8 6l-3.5 3.5"
                      stroke="#0b1d3a"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </span>
              </button>
            </div>

            <div className="faq-right">
              {renderFaqAccordion('home')}
              <p className="faq-bottom-line">
                Tem outra pergunta?{' '}
                <a href="#/duvidas" className="faq-contact-link">Ver todas as dúvidas</a> ou{' '}
                <button
                  type="button"
                  className="faq-contact-link"
                  onClick={(e) => handleOpenContact(e.currentTarget)}
                >
                  fale diretamente conosco
                </button>
                .
              </p>
            </div>
          </div>
        </section>

        {/* Footer on Home page */}
        {renderFooter()}
      </main>

      {/* Subpage View (7 separate screens) */}
      {currentRoute.path !== 'home' && currentSubpage && (
        <div className="subpage-view">
          {/* Solid Blue Header sitting directly over bowl glow */}
          <header className="sub-hero subpage-header">
            <nav className="subpage-breadcrumb" aria-label="Navegação estrutural">
              <a href="#/" className="subpage-breadcrumb-link">Início</a>
              <span className="subpage-breadcrumb-sep">/</span>
              <span className="subpage-breadcrumb-current">{currentSubpage.label}</span>
            </nav>
            <div className="subpage-eyebrow">{currentSubpage.eyebrow}</div>
            <h1 className="subpage-h1" ref={subpageH1Ref}>
              {currentSubpage.title}
            </h1>
            <p className="subpage-intro">{currentSubpage.intro}</p>
          </header>

          {/* Subpage Body: Sticky Sidebar + Section Cards Column */}
          <div className="sub-body subpage-body">
            {/* Desktop Sticky Sidebar */}
            <aside className="subpage-sidebar" aria-label="Navegação da página">
              <div className="subpage-sidebar-title">Nesta página</div>
              <nav className="subpage-sidebar-nav">
                {currentSubpage.sections.map((sec) => (
                  <a
                    key={sec.id}
                    href={`#/${currentSubpage.id}/${sec.id}`}
                    className={`subpage-nav-link ${activeSectionId === sec.id ? 'active' : ''}`}
                    onClick={(e) => {
                      e.preventDefault();
                      window.location.hash = `#/${currentSubpage.id}/${sec.id}`;
                      const el = document.getElementById(sec.id);
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        setActiveSectionId(sec.id);
                      }
                    }}
                  >
                    {sec.title}
                  </a>
                ))}
              </nav>
            </aside>

            {/* Section Cards Column */}
            <div className="subpage-cards">
              {currentSubpage.sections.map((sec) => (
                <article
                  key={sec.id}
                  id={sec.id}
                  className="subpage-card"
                  data-section={sec.id}
                >
                  <div className="subpage-card-header">
                    {sec.stepNum ? (
                      <div className="subpage-step-num">{sec.stepNum}</div>
                    ) : (
                      sec.icon && <div className="subpage-card-icon">{sec.icon}</div>
                    )}
                    <div>
                      <h2 className="subpage-card-title">{sec.title}</h2>
                      {sec.meta && <div className="subpage-card-meta">{sec.meta}</div>}
                    </div>
                  </div>

                  <p className="subpage-card-desc">{sec.desc}</p>

                  <ul className="subpage-bullet-list">
                    {sec.bullets.map((b, bIdx) => (
                      <li key={bIdx} className="subpage-bullet-item">
                        <span className="subpage-bullet-dot" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>

                  <button
                    type="button"
                    className="subpage-card-talk-link"
                    onClick={(e) => handleOpenContactWithTopic(sec.title, e.currentTarget)}
                  >
                    <span>Falar sobre isso</span>
                    <span className="talk-arrow" aria-hidden="true">→</span>
                  </button>
                </article>
              ))}

              {/* Bottom CTA Band */}
              <div className="subpage-cta-band">
                <div className="subpage-cta-inner">
                  <h2>Pronto para transformar o Moodle da sua empresa?</h2>
                  <p>Fale com nossa equipe técnica e receba uma proposta em até 24 horas.</p>
                  <button
                    type="button"
                    className="btn lg"
                    data-open-contact
                    onClick={(e) =>
                      handleOpenContact(
                        e.currentTarget,
                        `Olá! Gostaria de conversar sobre ${currentSubpage.label} para o Moodle da minha empresa.`
                      )
                    }
                    style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
                  >
                    <span className="lbl">Falar com a CorpWise</span>
                    <span className="dot">
                      <svg className="chev" width="16" height="16" viewBox="0 0 12 12" fill="none">
                        <path
                          d="M4.5 2.5 8 6l-3.5 3.5"
                          stroke="#0b1d3a"
                          strokeWidth="1.6"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                      </svg>
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {renderFooter()}
        </div>
      )}

      {/* Dúvidas Subpage View */}
      {currentRoute.path === 'duvidas' && (
        <div className="subpage-view">
          <header className="sub-hero subpage-header">
            <nav className="subpage-breadcrumb" aria-label="Navegação estrutural">
              <a href="#/" className="subpage-breadcrumb-link">Início</a>
              <span className="subpage-breadcrumb-sep">/</span>
              <span className="subpage-breadcrumb-current">Dúvidas</span>
            </nav>
            <div className="subpage-eyebrow">DÚVIDAS FREQUENTES</div>
            <h1 className="subpage-h1" ref={subpageH1Ref}>
              Perguntas frequentes
            </h1>
            <p className="subpage-intro">
              Tudo o que você precisa saber sobre a plataforma Moodle, nossos modelos de contratação, suporte contínuo e personalização para empresas.
            </p>
          </header>

          <div className="sub-body subpage-body subpage-body-duvidas">
            <div className="subpage-faq-container">
              {renderFaqAccordion('subpage')}

              <div className="subpage-cta-band">
                <div className="subpage-cta-inner">
                  <h2>Ficou com alguma dúvida?</h2>
                  <p>Nossa equipe técnica está à disposição para tirar qualquer dúvida sobre o Moodle da sua empresa.</p>
                  <div style={{ display: 'flex', gap: '12px', justifyContent: 'center', flexWrap: 'wrap', alignItems: 'center' }}>
                    <button
                      type="button"
                      className="btn lg"
                      data-open-contact
                      onClick={(e) =>
                        handleOpenContact(
                          e.currentTarget,
                          'Olá! Gostaria de tirar algumas dúvidas sobre os serviços da CorpWise.'
                        )
                      }
                      style={{ border: 0, font: 'inherit', cursor: 'pointer' }}
                    >
                      <span className="lbl">Falar com a CorpWise</span>
                      <span className="dot">
                        <svg className="chev" width="16" height="16" viewBox="0 0 12 12" fill="none">
                          <path
                            d="M4.5 2.5 8 6l-3.5 3.5"
                            stroke="#0b1d3a"
                            strokeWidth="1.6"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                      </span>
                    </button>
                    <button
                      type="button"
                      className="btn-secondary-degustacao"
                      onClick={(e) => handleOpenTrial(e.currentTarget)}
                    >
                      Pedir degustação
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {renderFooter()}
        </div>
      )}

      {/* Subpage View: Privacidade */}
      {currentRoute.path === 'privacidade' && (
        <div className="subpage-view">
          <header className="sub-hero subpage-header">
            <nav className="subpage-breadcrumb" aria-label="Navegação estrutural">
              <a href="#/" className="subpage-breadcrumb-link">Início</a>
              <span className="subpage-breadcrumb-sep">/</span>
              <span className="subpage-breadcrumb-current">Privacidade</span>
            </nav>
            <div className="subpage-eyebrow">PRIVACIDADE E PROTEÇÃO DE DADOS</div>
            <h1 className="subpage-h1" ref={subpageH1Ref}>
              Política de Privacidade
            </h1>
            <span className="subpage-h1-meta">
              Versão {LEGAL.versao} · Última atualização: {LEGAL.atualizadoEm}
            </span>
            <p className="subpage-intro">
              Transparência sobre como tratamos os seus dados pessoais, em conformidade com a Lei Geral de Proteção de Dados (LGPD - Lei nº 13.709/2018).
            </p>
          </header>

          <div className="sub-body subpage-body">
            <aside className="subpage-sidebar" aria-label="Navegação da página">
              <div className="subpage-sidebar-title">Nesta página</div>
              <nav className="subpage-sidebar-nav">
                {PRIVACIDADE_SECTIONS.map((sec) => (
                  <a
                    key={sec.id}
                    href={`#/privacidade/${sec.id}`}
                    className={`subpage-nav-link ${activeSectionId === sec.id ? 'active' : ''}`}
                    onClick={(e) => {
                      e.preventDefault();
                      window.location.hash = `#/privacidade/${sec.id}`;
                      const el = document.getElementById(sec.id);
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        setActiveSectionId(sec.id);
                      }
                    }}
                  >
                    {sec.title}
                  </a>
                ))}
              </nav>
            </aside>

            <div className="legal-content-col">
              <PrivacidadeContent onOpenPreferences={() => openPreferencesModal()} />
            </div>
          </div>

          {renderFooter()}
        </div>
      )}

      {/* Subpage View: Cookies */}
      {currentRoute.path === 'cookies' && (
        <div className="subpage-view">
          <header className="sub-hero subpage-header">
            <nav className="subpage-breadcrumb" aria-label="Navegação estrutural">
              <a href="#/" className="subpage-breadcrumb-link">Início</a>
              <span className="subpage-breadcrumb-sep">/</span>
              <span className="subpage-breadcrumb-current">Cookies</span>
            </nav>
            <div className="subpage-eyebrow">COOKIES E TECNOLOGIAS SEMELHANTES</div>
            <h1 className="subpage-h1" ref={subpageH1Ref}>
              Política de Cookies
            </h1>
            <span className="subpage-h1-meta">
              Versão {LEGAL.versao} · Última atualização: {LEGAL.atualizadoEm}
            </span>
            <p className="subpage-intro">
              Informações claras sobre o armazenamento local e as preferências de navegação utilizadas no nosso site.
            </p>
          </header>

          <div className="sub-body subpage-body">
            <aside className="subpage-sidebar" aria-label="Navegação da página">
              <div className="subpage-sidebar-title">Nesta página</div>
              <nav className="subpage-sidebar-nav">
                {COOKIES_SECTIONS.map((sec) => (
                  <a
                    key={sec.id}
                    href={`#/cookies/${sec.id}`}
                    className={`subpage-nav-link ${activeSectionId === sec.id ? 'active' : ''}`}
                    onClick={(e) => {
                      e.preventDefault();
                      window.location.hash = `#/cookies/${sec.id}`;
                      const el = document.getElementById(sec.id);
                      if (el) {
                        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        setActiveSectionId(sec.id);
                      }
                    }}
                  >
                    {sec.title}
                  </a>
                ))}
              </nav>
            </aside>

            <div className="legal-content-col">
              <CookiesContent onOpenPreferences={() => openPreferencesModal()} />
            </div>
          </div>

          {renderFooter()}
        </div>
      )}

      {/* Modal (native <dialog>) */}
      <dialog
        id="contact"
        ref={dialogRef}
        aria-labelledby="contact-title"
        onClose={handleDialogNativeClose}
        onClick={(e) => {
          if (e.target === dialogRef.current) {
            handleCloseContact();
          }
        }}
      >
        <button
          type="button"
          className="contact-close-btn"
          onClick={handleCloseContact}
          aria-label="Fechar"
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path
              d="M2 2L12 12M12 2L2 12"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </button>

        {submitSuccess ? (
          <div style={{ textAlign: 'center', padding: '16px 0 8px' }}>
            <div
              style={{
                width: 48,
                height: 48,
                borderRadius: '50%',
                background: '#2fe0d0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
              }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path
                  d="M4 12.5L9.5 18L20 6"
                  stroke="#0b1d3a"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <h2
              style={{
                fontSize: '26px',
                fontWeight: 500,
                letterSpacing: '-0.03em',
                color: 'var(--text)',
                marginBottom: '8px',
              }}
            >
              Gmail aberto!
            </h2>
            <p
              style={{
                fontSize: '15px',
                color: 'var(--text-2)',
                lineHeight: 1.45,
                maxWidth: '420px',
                margin: '0 auto',
              }}
            >
              Revise a mensagem na aba do Gmail e clique em Enviar para concluir. Se a aba não abriu, use o botão abaixo.
            </p>

            <div className="contact-confirm-actions">
              <button
                type="button"
                onClick={handleOpenGmailAgain}
                style={{
                  padding: '10px 24px',
                  borderRadius: '999px',
                  background: 'var(--chip)',
                  color: 'var(--text)',
                  fontSize: '14px',
                  fontWeight: 500,
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'background 0.2s ease',
                }}
              >
                Abrir o Gmail de novo
              </button>
              <button
                type="button"
                onClick={() => {
                  handleCloseContact();
                  setTimeout(() => {
                    setSubmitSuccess(false);
                    setPopupBlockedUrl(null);
                    setFormState({ nome: '', email: '', empresa: '', mensagem: '' });
                    setTouchedFields({});
                  }, 300);
                }}
                style={{
                  padding: '10px 28px',
                  borderRadius: '999px',
                  background: 'var(--btn-bg)',
                  color: 'var(--btn-fg)',
                  fontSize: '14px',
                  fontWeight: 500,
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'opacity 0.2s ease',
                }}
              >
                Fechar
              </button>
            </div>

            {popupBlockedUrl && (
              <p id="contact-status" role="status" aria-live="polite">
                Seu navegador bloqueou a nova aba.{' '}
                <a
                  href={popupBlockedUrl}
                  target="_blank"
                  rel="noopener"
                  style={{ color: 'inherit', textDecoration: 'underline', fontWeight: 600 }}
                >
                  Clique aqui
                </a>{' '}
                para abrir o Gmail.
              </p>
            )}
          </div>
        ) : (
          <>
            <div className="contact-eyebrow">Fale conosco</div>
            <h2 id="contact-title">Fale com a CorpWise</h2>
            <p className="contact-intro">
              Escreva a sua mensagem e abriremos o Gmail já preenchido, é só revisar e clicar em Enviar.
            </p>

            <form className="contact-form" onSubmit={handleSubmit}>
              <div className="contact-field">
                <label className="contact-field-label" htmlFor="contact-nome">
                  Nome
                </label>
                <input
                  id="contact-nome"
                  name="nome"
                  type="text"
                  required
                  autoComplete="name"
                  className={`contact-control ${touchedFields.nome ? 'touched' : ''}`}
                  value={formState.nome}
                  onChange={(e) => setFormState((prev) => ({ ...prev, nome: e.target.value }))}
                  onBlur={() => setTouchedFields((prev) => ({ ...prev, nome: true }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="contact-email">
                  E-mail
                </label>
                <input
                  id="contact-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  className={`contact-control ${touchedFields.email ? 'touched' : ''}`}
                  value={formState.email}
                  onChange={(e) => setFormState((prev) => ({ ...prev, email: e.target.value }))}
                  onBlur={() => setTouchedFields((prev) => ({ ...prev, email: true }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="contact-empresa">
                  Empresa
                </label>
                <input
                  id="contact-empresa"
                  name="empresa"
                  type="text"
                  autoComplete="organization"
                  className="contact-control"
                  value={formState.empresa}
                  onChange={(e) => setFormState((prev) => ({ ...prev, empresa: e.target.value }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="contact-mensagem">
                  Mensagem
                </label>
                <textarea
                  id="contact-mensagem"
                  name="mensagem"
                  rows={5}
                  required
                  placeholder="Ex.: queremos integrar o Moodle ao nosso RH e personalizar o tema com a nossa marca."
                  className={`contact-control ${touchedFields.mensagem ? 'touched' : ''}`}
                  value={formState.mensagem}
                  onChange={(e) => setFormState((prev) => ({ ...prev, mensagem: e.target.value }))}
                  onBlur={() => setTouchedFields((prev) => ({ ...prev, mensagem: true }))}
                />
              </div>

              <div style={{ marginTop: '8px' }}>
                <button type="submit" className="btn contact-submit-btn">
                  <span className="lbl">Abrir no Gmail</span>
                  <span className="dot">
                    <svg className="chev" width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path
                        d="M4.5 2.5 8 6l-3.5 3.5"
                        stroke="#0b1d3a"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                </button>
              </div>

              <div className="contact-fallback">
                <span>Não usa o Gmail? </span>
                <a href="#" onClick={handleOpenEmailApp}>
                  Abrir no app de e-mail
                </a>
              </div>

              <p className="form-privacy-note">
                Ao continuar, abrimos o Gmail com a sua mensagem pronta. Os dados só chegam até nós quando você clicar em Enviar, e são usados para responder ao seu contato. Veja a nossa{' '}
                <a
                  href="#/privacidade"
                  className="form-privacy-link"
                  onClick={() => handleCloseContact()}
                >
                  Política de Privacidade
                </a>
                .
              </p>

              {popupBlockedUrl && (
                <p id="contact-status" role="status" aria-live="polite">
                  Seu navegador bloqueou a nova aba.{' '}
                  <a
                    href={popupBlockedUrl}
                    target="_blank"
                    rel="noopener"
                    style={{ color: 'inherit', textDecoration: 'underline', fontWeight: 600 }}
                  >
                    Clique aqui
                  </a>{' '}
                  para abrir o Gmail.
                </p>
              )}
            </form>
          </>
        )}
      </dialog>

      {/* Trial / Access Request Modal (native <dialog id="trial">) */}
      <dialog
        id="trial"
        ref={trialDialogRef}
        aria-labelledby="trial-title"
        onClose={handleTrialDialogNativeClose}
        onClick={(e) => {
          if (e.target === trialDialogRef.current) {
            handleCloseTrial();
          }
        }}
      >
        <button
          type="button"
          className="contact-close-btn"
          onClick={handleCloseTrial}
          aria-label="Fechar"
        >
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path
              d="M2 2L12 12M12 2L2 12"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
            />
          </svg>
        </button>

        {trialSubmitSuccess ? (
          <div style={{ textAlign: 'center', padding: '16px 0 8px' }}>
            <div
              style={{
                width: 48,
                height: 48,
                borderRadius: '50%',
                background: '#2fe0d0',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 16px',
              }}
            >
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
                <path
                  d="M4 12.5L9.5 18L20 6"
                  stroke="#0b1d3a"
                  strokeWidth="2.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </div>
            <h2
              style={{
                fontSize: '26px',
                fontWeight: 500,
                letterSpacing: '-0.03em',
                color: 'var(--text)',
                marginBottom: '8px',
              }}
            >
              Gmail aberto!
            </h2>
            <p
              style={{
                fontSize: '15px',
                color: 'var(--text-2)',
                lineHeight: 1.45,
                maxWidth: '420px',
                margin: '0 auto',
              }}
            >
              Revise o pedido na aba do Gmail e clique em Enviar para concluir. Quando recebermos, criamos o seu usuário e respondemos por e-mail com o acesso.
            </p>

            <div className="contact-confirm-actions">
              <button
                type="button"
                onClick={handleTrialOpenGmailAgain}
                style={{
                  padding: '10px 24px',
                  borderRadius: '999px',
                  background: 'var(--chip)',
                  color: 'var(--text)',
                  fontSize: '14px',
                  fontWeight: 500,
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'background 0.2s ease',
                }}
              >
                Abrir o Gmail de novo
              </button>
              <button
                type="button"
                onClick={() => {
                  handleCloseTrial();
                  setTimeout(() => {
                    setTrialSubmitSuccess(false);
                    setTrialPopupBlockedUrl(null);
                    setTrialFormState({ nome: '', email: '', empresa: '', porte: '' });
                    setSelectedChips([]);
                    setTrialTouchedFields({});
                  }, 300);
                }}
                style={{
                  padding: '10px 28px',
                  borderRadius: '999px',
                  background: 'var(--btn-bg)',
                  color: 'var(--btn-fg)',
                  fontSize: '14px',
                  fontWeight: 500,
                  border: 'none',
                  cursor: 'pointer',
                  transition: 'opacity 0.2s ease',
                }}
              >
                Fechar
              </button>
            </div>

            <div style={{ marginTop: '22px', textAlign: 'center' }}>
              <a
                href="https://corpwisegestao.com.br/login/index.php"
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  color: 'var(--link)',
                  textDecoration: 'none',
                  fontSize: '13.5px',
                  fontWeight: 500,
                }}
              >
                Já tem acesso? Entre no Moodle →
              </a>
            </div>

            {trialPopupBlockedUrl && (
              <p id="trial-status" role="status" aria-live="polite">
                Seu navegador bloqueou a nova aba.{' '}
                <a
                  href={trialPopupBlockedUrl}
                  target="_blank"
                  rel="noopener"
                  style={{ color: 'inherit', textDecoration: 'underline', fontWeight: 600 }}
                >
                  Clique aqui
                </a>{' '}
                para abrir o Gmail.
              </p>
            )}
          </div>
        ) : (
          <>
            <div className="contact-eyebrow">Ambiente de teste</div>
            <h2 id="trial-title">Pedir acesso ao ambiente de teste</h2>
            <p className="contact-intro">
              Experimente o Moodle corporativo na prática com temas, plugins e relatórios prontos. Enviaremos os dados de acesso por e-mail.
            </p>

            <form className="contact-form" onSubmit={handleTrialSubmit}>
              <div className="contact-field">
                <label className="contact-field-label" htmlFor="trial-nome">
                  Nome completo
                </label>
                <input
                  id="trial-nome"
                  name="nome"
                  type="text"
                  required
                  autoComplete="name"
                  placeholder="Seu nome completo"
                  className={`contact-control ${trialTouchedFields.nome ? 'touched' : ''}`}
                  value={trialFormState.nome}
                  onChange={(e) => setTrialFormState((prev) => ({ ...prev, nome: e.target.value }))}
                  onBlur={() => setTrialTouchedFields((prev) => ({ ...prev, nome: true }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="trial-email">
                  E-mail corporativo
                </label>
                <input
                  id="trial-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  placeholder="voce@suaempresa.com.br"
                  className={`contact-control ${trialTouchedFields.email ? 'touched' : ''}`}
                  value={trialFormState.email}
                  onChange={(e) => setTrialFormState((prev) => ({ ...prev, email: e.target.value }))}
                  onBlur={() => setTrialTouchedFields((prev) => ({ ...prev, email: true }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="trial-empresa">
                  Empresa
                </label>
                <input
                  id="trial-empresa"
                  name="empresa"
                  type="text"
                  required
                  autoComplete="organization"
                  placeholder="Nome da sua empresa"
                  className={`contact-control ${trialTouchedFields.empresa ? 'touched' : ''}`}
                  value={trialFormState.empresa}
                  onChange={(e) => setTrialFormState((prev) => ({ ...prev, empresa: e.target.value }))}
                  onBlur={() => setTrialTouchedFields((prev) => ({ ...prev, empresa: true }))}
                />
              </div>

              <div className="contact-field">
                <label className="contact-field-label" htmlFor="trial-porte">
                  Porte da empresa
                </label>
                <div className="select-wrapper">
                  <select
                    id="trial-porte"
                    name="porte"
                    required
                    className={`contact-control ${trialTouchedFields.porte ? 'touched' : ''}`}
                    value={trialFormState.porte}
                    onChange={(e) => setTrialFormState((prev) => ({ ...prev, porte: e.target.value }))}
                    onBlur={() => setTrialTouchedFields((prev) => ({ ...prev, porte: true }))}
                  >
                    <option value="" disabled>
                      Selecione o porte da sua empresa
                    </option>
                    <option value="Até 100 colaboradores">Até 100 colaboradores</option>
                    <option value="101 a 500 colaboradores">101 a 500 colaboradores</option>
                    <option value="501 a 2.000 colaboradores">501 a 2.000 colaboradores</option>
                    <option value="Mais de 2.000 colaboradores">Mais de 2.000 colaboradores</option>
                  </select>
                  <svg
                    className="select-chevron"
                    width="14"
                    height="14"
                    viewBox="0 0 12 12"
                    fill="none"
                  >
                    <path
                      d="M2.5 4.5L6 8L9.5 4.5"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </div>

              <div className="trial-chips-group">
                <label className="contact-field-label">
                  O que você quer ver? (opcional)
                </label>
                <div className="trial-chips-list" role="group" aria-label="O que você quer ver?">
                  {TRIAL_CHIPS.map((chip) => {
                    const isSelected = selectedChips.includes(chip);
                    return (
                      <button
                        key={chip}
                        type="button"
                        role="checkbox"
                        aria-checked={isSelected}
                        className={`trial-chip ${isSelected ? 'selected' : ''}`}
                        onClick={() => handleToggleChip(chip)}
                      >
                        {isSelected && (
                          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                            <path
                              d="M2.5 6L5 8.5L9.5 3.5"
                              stroke="currentColor"
                              strokeWidth="1.8"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                            />
                          </svg>
                        )}
                        <span>{chip}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div style={{ marginTop: '8px' }}>
                <button type="submit" className="btn contact-submit-btn">
                  <span className="lbl">Abrir no Gmail</span>
                  <span className="dot">
                    <svg className="chev" width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <path
                        d="M4.5 2.5 8 6l-3.5 3.5"
                        stroke="#0b1d3a"
                        strokeWidth="1.6"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      />
                    </svg>
                  </span>
                </button>
              </div>

              <div className="contact-fallback">
                <span>Não usa o Gmail? </span>
                <a href="#" onClick={handleTrialOpenEmailApp}>
                  Abrir no app de e-mail
                </a>
              </div>

              <p className="form-privacy-note">
                Usaremos os seus dados para criar o seu usuário de teste e responder ao pedido. Eles só chegam até nós quando você clicar em Enviar no Gmail. Veja a nossa{' '}
                <a
                  href="#/privacidade"
                  className="form-privacy-link"
                  onClick={() => handleCloseTrial()}
                >
                  Política de Privacidade
                </a>
                .
              </p>

              {trialPopupBlockedUrl && (
                <p id="trial-status" role="status" aria-live="polite">
                  Seu navegador bloqueou a nova aba.{' '}
                  <a
                    href={trialPopupBlockedUrl}
                    target="_blank"
                    rel="noopener"
                    style={{ color: 'inherit', textDecoration: 'underline', fontWeight: 600 }}
                  >
                    Clique aqui
                  </a>{' '}
                  para abrir o Gmail.
                </p>
              )}
            </form>
          </>
        )}
      </dialog>

      {/* First-level Cookie Banner */}
      {showCookieBanner && (
        <aside
          id="cookie-banner"
          role="region"
          aria-label="Aviso de cookies"
          aria-live="polite"
        >
          <div className="cookie-banner-inner">
            <div className="cookie-banner-content">
              <div className="cookie-banner-title">Cookies e privacidade</div>
              <p className="cookie-banner-desc">
                Usamos cookies necessários para o site funcionar e, com a sua permissão, guardamos a sua preferência de tema (claro/escuro). Não usamos rastreadores nem cookies de marketing. Saiba mais na nossa{' '}
                <a href="#/cookies">Política de Cookies</a> e na{' '}
                <a href="#/privacidade">Política de Privacidade</a>.
              </p>
            </div>
            <div className="cookie-banner-actions">
              <button
                type="button"
                className="btn-cookie"
                onClick={handleRejectNonNecessary}
              >
                Recusar cookies que não são necessários
              </button>
              <button
                type="button"
                className="btn-cookie"
                onClick={handleOpenCustomize}
              >
                Personalizar
              </button>
              <button
                type="button"
                className="btn-cookie"
                onClick={handleAcceptAll}
              >
                Aceitar tudo
              </button>
            </div>
          </div>
        </aside>
      )}

      {/* Cookie Preferences Modal (<dialog id="cookie-prefs">) */}
      <dialog
        id="cookie-prefs"
        ref={cookiePrefsDialogRef}
        aria-labelledby="cookie-prefs-title"
        onClose={() => {
          if (!isMobileMenuOpen && !dialogRef.current?.open && !trialDialogRef.current?.open) {
            document.body.style.overflow = '';
          }
          if (cookiePrefsOpenerRef.current) {
            cookiePrefsOpenerRef.current.focus();
          }
        }}
        onClick={(e) => {
          if (e.target === cookiePrefsDialogRef.current) {
            closePreferencesModal();
          }
        }}
      >
        <div className="cookie-prefs-card">
          <button
            type="button"
            className="contact-close-btn"
            onClick={() => closePreferencesModal()}
            aria-label="Fechar"
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path
                d="M2 2L12 12M12 2L2 12"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          </button>

          <div className="cookie-prefs-header">
            <div className="cookie-prefs-eyebrow">PREFERÊNCIAS DE PRIVACIDADE</div>
            <h2 id="cookie-prefs-title" className="cookie-prefs-title">
              Gerenciar preferências de cookies
            </h2>
          </div>

          <p className="cookie-prefs-intro">
            Você pode escolher quais categorias de cookies e dados deseja permitir durante a sua navegação. Os cookies estritamente necessários não podem ser desativados pois o site depende deles para funcionar. Saiba mais na nossa{' '}
            <a href="#/cookies" onClick={() => closePreferencesModal(true)}>
              Política de Cookies
            </a>{' '}
            e na{' '}
            <a href="#/privacidade" onClick={() => closePreferencesModal(true)}>
              Política de Privacidade
            </a>
            .
          </p>

          <div className="cookie-category-list">
            <div className="cookie-category-item">
              <div className="cookie-category-top">
                <span className="cookie-category-name">Estritamente necessários</span>
                <span className="always-active-badge">Sempre ativo</span>
              </div>
              <p className="cookie-category-desc">
                Fundamentais para a navegação, segurança, roteamento e estabilidade do site. Não coletam dados para fins publicitários.
              </p>
            </div>

            <div className="cookie-category-item">
              <div className="cookie-category-top">
                <label htmlFor="pref-toggle-theme" className="cookie-category-name" style={{ cursor: 'pointer' }}>
                  Preferências
                </label>
                <button
                  id="pref-toggle-theme"
                  type="button"
                  role="switch"
                  aria-checked={prefsAllowed}
                  className="cookie-switch"
                  onClick={() => setPrefsAllowed((prev) => !prev)}
                  aria-label="Permitir cookies de preferências"
                >
                  <span className="cookie-switch-thumb" />
                </button>
              </div>
              <p className="cookie-category-desc">
                Permitem memorizar as suas configurações entre visitas, como a escolha entre o modo claro e o modo escuro.
              </p>
            </div>
          </div>

          {storedConsent?.ts && (
            <p className="cookie-prefs-meta">
              Última escolha: {new Date(storedConsent.ts).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
            </p>
          )}

          <div className="cookie-prefs-actions">
            <button
              type="button"
              className="btn-cookie"
              onClick={handlePrefsRejectNonNecessary}
            >
              Recusar cookies que não são necessários
            </button>
            <button
              type="button"
              className="btn-cookie"
              onClick={handlePrefsSaveChoices}
            >
              Salvar minhas escolhas
            </button>
            <button
              type="button"
              className="btn-cookie"
              onClick={handlePrefsAcceptAll}
            >
              Aceitar tudo
            </button>
          </div>

          <div
            role="status"
            aria-live="polite"
            className="cookie-prefs-status"
          >
            {prefsFeedback}
          </div>
        </div>
      </dialog>
    </>
  );
}
